//! Type d'erreur unifié pour GemmaClaw.
//!
//! Conçu pour :
//! 1. Donner des messages utilisateur clairs (FR + EN)
//! 2. Préserver la chaîne de causes (`source`)
//! 3. Être convertible vers/depuis `anyhow::Error` aux frontières

use std::path::PathBuf;
use thiserror::Error;

/// Alias `Result` standard de la crate.
pub type Result<T> = std::result::Result<T, GemmaError>;

/// Erreurs de premier niveau de GemmaClaw.
#[derive(Debug, Error)]
pub enum GemmaError {
    #[error("Modèle introuvable : {path}")]
    ModelNotFound { path: PathBuf },

    #[error("Échec du chargement du modèle GGUF : {reason}")]
    ModelLoad { reason: String, #[source] source: Option<anyhow::Error> },

    #[error("Tokenizer introuvable près de {path}. Place tokenizer.json à côté du .gguf.")]
    TokenizerNotFound { path: PathBuf },

    #[error("Erreur de tokenisation : {0}")]
    Tokenize(String),

    #[error("Erreur d'inférence : {0}")]
    Inference(String),

    #[error("Modèle non chargé. Importe d'abord un .gguf via Paramètres.")]
    ModelNotLoaded,

    #[error("Génération annulée par l'utilisateur")]
    Cancelled,

    #[error("Limite d'étapes de l'agent atteinte ({max} étapes)")]
    MaxStepsReached { max: usize },

    #[error("Skill inconnu : {0}")]
    UnknownSkill(String),

    #[error("Argument invalide pour le skill {skill} : {reason}")]
    InvalidArgs { skill: String, reason: String },

    #[error("Erreur réseau : {0}")]
    Network(#[from] reqwest::Error),

    #[error("Erreur SQLite : {0}")]
    Database(#[from] rusqlite::Error),

    #[error("Erreur d'E/S : {0}")]
    Io(#[from] std::io::Error),

    #[error("Erreur JSON : {0}")]
    Json(#[from] serde_json::Error),

    #[error("Tâche tokio annulée : {0}")]
    JoinError(#[from] tokio::task::JoinError),

    #[error("Erreur interne : {0}")]
    Internal(String),
}

impl GemmaError {
    /// Indique si l'erreur est récupérable (l'app peut continuer).
    #[must_use]
    pub fn is_recoverable(&self) -> bool {
        matches!(
            self,
            Self::Network(_)
                | Self::UnknownSkill(_)
                | Self::InvalidArgs { .. }
                | Self::Cancelled
                | Self::MaxStepsReached { .. }
        )
    }

    /// Message court adapté à l'affichage dans une barre d'erreur.
    #[must_use]
    pub fn user_message(&self) -> String {
        match self {
            Self::ModelNotLoaded     => "Aucun modèle chargé".into(),
            Self::ModelNotFound { .. } => "Fichier .gguf introuvable".into(),
            Self::TokenizerNotFound { .. } => "tokenizer.json manquant".into(),
            Self::Cancelled          => "Génération annulée".into(),
            Self::Network(_)         => "Connexion impossible".into(),
            other                    => other.to_string(),
        }
    }
}

// Conversion depuis anyhow pour les sites d'appel hors API publique.
impl From<anyhow::Error> for GemmaError {
    fn from(e: anyhow::Error) -> Self {
        Self::Internal(format!("{e:#}"))
    }
}

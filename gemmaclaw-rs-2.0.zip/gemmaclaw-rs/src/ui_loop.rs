//! Boucle d'événements UI Slint commune (desktop + Android).
//!
//! Branche les callbacks `MainWindow` (envoyer message, stop, clear, settings,
//! import modèle) sur l'`AgentLoop` et la `MemoryRepository`.

use crate::app::App;
use crate::llm::agent_loop::AgentResponse;
use crate::llm::prompt_builder::ChatMessage;
use crate::settings::SettingsData;
use crate::{AppSettings_, ChatMessage_, MainWindow};

use slint::{ComponentHandle, Model, ModelRc, VecModel};
use std::path::Path;
use std::rc::Rc;
use std::sync::Arc;

pub fn run(app: Arc<App>) -> anyhow::Result<()> {
    let ui = MainWindow::new()?;

    bootstrap_history(&app, &ui)?;
    bootstrap_settings(&app, &ui);

    wire_send(&app, &ui);
    wire_stop(&app, &ui);
    wire_clear(&app, &ui);
    wire_save_settings(&app, &ui);
    wire_import_model(&app, &ui);

    ui.run()?;
    Ok(())
}

fn bootstrap_history(app: &Arc<App>, ui: &MainWindow) -> anyhow::Result<()> {
    let history = app.rt.block_on(app.memory.get_history(100)).unwrap_or_default();
    let msgs: Vec<ChatMessage_> = history.into_iter().enumerate()
        .map(|(i, (c, is_u))| ChatMessage_ {
            content: c.into(), is_user: is_u, is_loading: false, id: i as i32,
        })
        .collect();
    ui.set_messages(ModelRc::from(Rc::new(VecModel::from(msgs))));
    Ok(())
}

fn bootstrap_settings(app: &Arc<App>, ui: &MainWindow) {
    let s = app.settings.get();
    ui.set_settings(AppSettings_ {
        model_path:  s.model_path.into(),
        max_tokens:  s.max_tokens as i32,
        temperature: s.temperature,
        memory:      s.memory_enabled,
        streaming:   s.streaming_enabled,
    });
    ui.set_model_loaded(app.engine.is_loaded());
    ui.set_app_version(format!("v{}", crate::VERSION).into());
}

fn wire_send(app: &Arc<App>, ui: &MainWindow) {
    let app_ref = Arc::clone(app);
    let weak    = ui.as_weak();
    ui.on_send_message(move |text| {
        let text = text.to_string();
        if text.trim().is_empty() { return; }

        // Affiche immédiatement le message utilisateur + un placeholder.
        if let Some(ui) = weak.upgrade() {
            push_message(&ui, &text, true,  false);
            push_message(&ui, "",    false, true);
            ui.set_is_generating(true);
        }

        let app  = Arc::clone(&app_ref);
        let weak = weak.clone();
        app.rt.spawn(async move {
            // Sauvegarde le message utilisateur
            let _ = app.memory.save_message(&text, true).await;

            // Récupère l'historique en async (pas de block_on imbriqué !)
            let raw = app.memory.get_history(30).await.unwrap_or_default();
            let history: Vec<ChatMessage> = raw.into_iter()
                .map(|(c, u)| ChatMessage { content: c, is_user: u })
                .collect();

            match app.agent.respond(&text, &history).await {
                Ok(AgentResponse::Text(resp)) => {
                    let _ = app.memory.save_message(&resp, false).await;
                    let weak2 = weak.clone();
                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = weak2.upgrade() {
                            replace_last(&ui, &resp);
                            ui.set_is_generating(false);
                        }
                    });
                }
                Ok(AgentResponse::Stream(mut rx)) => {
                    let mut full = String::new();
                    while let Some(chunk) = rx.recv().await {
                        full.push_str(&chunk);
                        let snapshot = full.clone();
                        let weak2 = weak.clone();
                        let _ = slint::invoke_from_event_loop(move || {
                            if let Some(ui) = weak2.upgrade() {
                                replace_last(&ui, &snapshot);
                            }
                        });
                    }
                    let _ = app.memory.save_message(&full, false).await;
                    let weak2 = weak.clone();
                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = weak2.upgrade() {
                            ui.set_is_generating(false);
                        }
                    });
                }
                Err(e) => {
                    let msg = format!("⚠️ {}", e.user_message());
                    let weak2 = weak.clone();
                    let _ = slint::invoke_from_event_loop(move || {
                        if let Some(ui) = weak2.upgrade() {
                            replace_last(&ui, &msg);
                            ui.set_is_generating(false);
                        }
                    });
                }
            }
        });
    });
}

fn wire_stop(app: &Arc<App>, ui: &MainWindow) {
    let app_ref = Arc::clone(app);
    ui.on_stop_generation(move || {
        app_ref.agent.stop();
    });
}

fn wire_clear(app: &Arc<App>, ui: &MainWindow) {
    let app_ref = Arc::clone(app);
    let weak    = ui.as_weak();
    ui.on_clear_chat(move || {
        let app  = Arc::clone(&app_ref);
        let weak = weak.clone();
        app_ref.rt.spawn(async move {
            let _ = app.memory.clear().await;
            let _ = slint::invoke_from_event_loop(move || {
                if let Some(ui) = weak.upgrade() {
                    ui.set_messages(ModelRc::from(
                        Rc::new(VecModel::<ChatMessage_>::from(Vec::new()))
                    ));
                }
            });
        });
    });
}

fn wire_save_settings(app: &Arc<App>, ui: &MainWindow) {
    let app_ref = Arc::clone(app);
    ui.on_save_settings(move |s| {
        let mut current = app_ref.settings.get();
        current.model_path        = s.model_path.to_string();
        current.max_tokens        = s.max_tokens as usize;
        current.temperature       = s.temperature;
        current.memory_enabled    = s.memory;
        current.streaming_enabled = s.streaming;
        if let Err(e) = app_ref.settings.update(current) {
            log::error!("Save settings failed: {e}");
        }
    });
}

fn wire_import_model(app: &Arc<App>, ui: &MainWindow) {
    let app_ref = Arc::clone(app);
    let weak    = ui.as_weak();
    ui.on_import_model(move || {
        let path = app_ref.settings.model_path();
        if path.is_empty() {
            if let Some(ui) = weak.upgrade() {
                ui.set_import_error("Aucun chemin configuré — utilise Paramètres".into());
            }
            return;
        }
        let app  = Arc::clone(&app_ref);
        let weak = weak.clone();
        app_ref.rt.spawn(async move {
            if let Some(ui) = weak.upgrade() {
                let _ = slint::invoke_from_event_loop({
                    let weak = weak.clone();
                    move || {
                        if let Some(ui) = weak.upgrade() {
                            ui.set_import_progress(0);
                            ui.set_import_error("".into());
                        }
                    }
                });
                let _ = ui;
            }

            let engine = Arc::clone(&app.engine);
            let path_buf = std::path::PathBuf::from(path);
            let res = tokio::task::spawn_blocking(move || engine.load(&path_buf)).await;

            let (ok, err) = match res {
                Ok(Ok(()))  => (true,  String::new()),
                Ok(Err(e))  => (false, e.user_message()),
                Err(e)      => (false, format!("Tâche : {e}")),
            };
            let _ = slint::invoke_from_event_loop(move || {
                if let Some(ui) = weak.upgrade() {
                    ui.set_model_loaded(ok);
                    ui.set_import_progress(-1);
                    ui.set_import_error(err.into());
                }
            });
        });
    });
}

// ── Helpers UI ────────────────────────────────────────────────────────────────

fn vec_model(ui: &MainWindow) -> Option<Rc<VecModel<ChatMessage_>>> {
    ui.get_messages().as_any().downcast_ref::<VecModel<ChatMessage_>>().cloned().map(Rc::new)
        .or_else(|| {
            // Si le model n'est pas un VecModel (cas startup), on en crée un nouveau.
            let v = Rc::new(VecModel::<ChatMessage_>::from(Vec::new()));
            ui.set_messages(ModelRc::from(Rc::clone(&v)));
            Some(v)
        })
}

fn push_message(ui: &MainWindow, content: &str, is_user: bool, is_loading: bool) {
    let Some(model) = vec_model(ui) else { return };
    let id = model.row_count() as i32;
    model.push(ChatMessage_ {
        content: content.into(), is_user, is_loading, id,
    });
}

fn replace_last(ui: &MainWindow, new_content: &str) {
    let Some(model) = vec_model(ui) else { return };
    let n = model.row_count();
    if n == 0 { return; }
    let last = n - 1;
    if let Some(mut msg) = model.row_data(last) {
        if msg.is_loading || !msg.is_user {
            msg.content    = new_content.into();
            msg.is_loading = false;
            model.set_row_data(last, msg);
        }
    }
}

// `Path` re-export silencieux pour les futurs usages
#[allow(dead_code)]
fn _silence(_: &Path) {}

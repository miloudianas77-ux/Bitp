//! Persistance des préférences utilisateur dans un JSON.
//!
//! Lecture lock-free via `parking_lot::RwLock` ; écriture atomique
//! (`tempfile + rename`) pour ne jamais corrompre le fichier en cas de crash.

use crate::error::Result;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::Arc;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(default)]
pub struct SettingsData {
    pub model_path:        String,
    pub max_tokens:        usize,
    pub temperature:       f32,
    pub top_k:             usize,
    pub top_p:             f32,
    pub repeat_penalty:    f32,
    pub memory_enabled:    bool,
    pub streaming_enabled: bool,
    pub theme:             Theme,
    pub language:          String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Theme { System, Light, Dark }

impl Default for Theme { fn default() -> Self { Self::System } }

impl Default for SettingsData {
    fn default() -> Self {
        Self {
            model_path:        String::new(),
            max_tokens:        512,
            temperature:       0.7,
            top_k:             40,
            top_p:             0.95,
            repeat_penalty:    1.1,
            memory_enabled:    true,
            streaming_enabled: true,
            theme:             Theme::System,
            language:          "fr".into(),
        }
    }
}

impl SettingsData {
    /// Valide les bornes — appelée au chargement et à la mise à jour.
    pub fn clamp(&mut self) {
        self.max_tokens     = self.max_tokens.clamp(16, 4096);
        self.temperature    = self.temperature.clamp(0.0, 2.0);
        self.top_k          = self.top_k.clamp(0, 1000);
        self.top_p          = self.top_p.clamp(0.0, 1.0);
        self.repeat_penalty = self.repeat_penalty.clamp(0.5, 2.0);
    }
}

/// Wrapper thread-safe.
pub struct Settings {
    data: Arc<RwLock<SettingsData>>,
    path: Option<PathBuf>,
}

impl Settings {
    /// Charge depuis un fichier JSON. Si absent ou corrompu : valeurs par défaut.
    pub fn load(path: &Path) -> Self {
        let mut data = if path.exists() {
            match std::fs::read_to_string(path) {
                Ok(s) => serde_json::from_str(&s).unwrap_or_else(|e| {
                    log::warn!("Corrupt settings file ({e}) — using defaults");
                    SettingsData::default()
                }),
                Err(e) => {
                    log::warn!("Cannot read settings: {e} — using defaults");
                    SettingsData::default()
                }
            }
        } else {
            SettingsData::default()
        };
        data.clamp();
        Self { data: Arc::new(RwLock::new(data)), path: Some(path.to_path_buf()) }
    }

    pub fn in_memory() -> Self {
        Self {
            data: Arc::new(RwLock::new(SettingsData::default())),
            path: None,
        }
    }

    pub fn get(&self) -> SettingsData { self.data.read().clone() }

    /// Met à jour et **persiste atomiquement** (tempfile + rename).
    pub fn update(&self, mut new_data: SettingsData) -> Result<()> {
        new_data.clamp();
        *self.data.write() = new_data.clone();
        if let Some(ref path) = self.path {
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent)?;
            }
            atomic_write(path, &serde_json::to_vec_pretty(&new_data)?)?;
        }
        Ok(())
    }

    // Accesseurs pratiques (lock court).
    pub fn model_path(&self)        -> String { self.data.read().model_path.clone() }
    pub fn memory_enabled(&self)    -> bool   { self.data.read().memory_enabled }
    pub fn streaming_enabled(&self) -> bool   { self.data.read().streaming_enabled }
    pub fn max_tokens(&self)        -> usize  { self.data.read().max_tokens }
    pub fn temperature(&self)       -> f32    { self.data.read().temperature }
}

/// Écriture atomique : `path.tmp` puis `rename(path.tmp, path)`.
fn atomic_write(path: &Path, bytes: &[u8]) -> Result<()> {
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, bytes)?;
    std::fs::rename(&tmp, path)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn defaults_are_sane() {
        let s = SettingsData::default();
        assert!(s.memory_enabled);
        assert_eq!(s.top_k, 40);
        assert!(s.temperature > 0.0);
    }

    #[test]
    fn clamp_pulls_extreme_values_back() {
        let mut s = SettingsData::default();
        s.temperature = 99.0;
        s.top_p       = -1.0;
        s.max_tokens  = 100_000;
        s.clamp();
        assert!(s.temperature <= 2.0);
        assert!(s.top_p >= 0.0);
        assert!(s.max_tokens <= 4096);
    }

    #[test]
    fn round_trip_load_save() {
        let dir  = tempdir().unwrap();
        let path = dir.path().join("settings.json");
        let s    = Settings::load(&path);
        let mut d = s.get();
        d.model_path = "/tmp/foo.gguf".into();
        d.temperature = 0.4;
        s.update(d.clone()).unwrap();
        let s2 = Settings::load(&path);
        assert_eq!(s2.get(), d);
    }

    #[test]
    fn corrupt_file_falls_back_to_defaults() {
        let dir  = tempdir().unwrap();
        let path = dir.path().join("settings.json");
        std::fs::write(&path, "}}invalid json{{").unwrap();
        let s = Settings::load(&path);
        assert_eq!(s.get(), SettingsData::default());
    }

    #[test]
    fn theme_serializes_lowercase() {
        let j = serde_json::to_string(&Theme::Dark).unwrap();
        assert_eq!(j, "\"dark\"");
    }
}

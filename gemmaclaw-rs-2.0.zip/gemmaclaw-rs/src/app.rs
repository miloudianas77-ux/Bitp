//! Cœur applicatif partagé entre desktop et Android.
//!
//! Construit l'arbre `engine + agent + skills + memory + settings` et expose
//! un `AppHandle` léger (`Clone`) pour les callbacks UI.

use crate::error::Result;
use crate::llm::agent_loop::AgentLoop;
use crate::llm::engine::GemmaEngine;
use crate::memory::MemoryRepository;
use crate::settings::Settings;
use crate::skills::SkillRegistry;

use std::path::{Path, PathBuf};
use std::sync::Arc;
use tokio::runtime::Runtime;

/// Application racine. Possède le runtime tokio.
pub struct App {
    pub engine:   Arc<GemmaEngine>,
    pub agent:    Arc<AgentLoop>,
    pub memory:   Arc<MemoryRepository>,
    pub settings: Arc<Settings>,
    pub skills:   Arc<SkillRegistry>,
    pub rt:       Runtime,
    pub data_dir: PathBuf,
}

impl App {
    pub fn new(data_dir: &Path) -> Result<Self> {
        std::fs::create_dir_all(data_dir)?;

        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .thread_name("gemmaclaw-worker")
            .enable_all()
            .build()?;

        let settings_path = data_dir.join("settings.json");
        let db_path       = data_dir.join("gemmaclaw.db");

        let settings = Arc::new(Settings::load(&settings_path));
        let memory   = Arc::new(MemoryRepository::open(&db_path)?);
        let engine   = Arc::new(GemmaEngine::new());
        let skills   = SkillRegistry::default_registry();

        // Tente le chargement du modèle si déjà configuré (non-bloquant pour l'UI).
        let mp = settings.model_path();
        if !mp.is_empty() {
            let engine_clone = Arc::clone(&engine);
            let path = PathBuf::from(mp);
            rt.spawn(async move {
                let path2 = path.clone();
                let res = tokio::task::spawn_blocking(move || engine_clone.load(&path2)).await;
                match res {
                    Ok(Ok(())) => log::info!("Model auto-loaded from {path:?}"),
                    Ok(Err(e)) => log::warn!("Auto-load failed: {e}"),
                    Err(e)     => log::error!("Auto-load join failed: {e}"),
                }
            });
        }

        let agent = Arc::new(AgentLoop::new(
            Arc::clone(&engine),
            Arc::clone(&skills),
            Arc::clone(&memory),
            Arc::clone(&settings),
        ));

        Ok(Self {
            engine, agent, memory, settings, skills, rt,
            data_dir: data_dir.to_path_buf(),
        })
    }

    /// Construit un handle clonable pour les callbacks Slint.
    pub fn handle(self: &Arc<Self>) -> AppHandle {
        AppHandle { inner: Arc::clone(self) }
    }
}

/// Handle léger — `Clone` peu coûteux (juste un `Arc<App>`).
#[derive(Clone)]
pub struct AppHandle {
    pub inner: Arc<App>,
}

impl std::ops::Deref for AppHandle {
    type Target = App;
    fn deref(&self) -> &App { &self.inner }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn app_creates_data_dir() {
        let dir = tempdir().unwrap();
        let sub = dir.path().join("subdir");
        let _ = App::new(&sub).unwrap();
        assert!(sub.exists());
    }

    #[test]
    fn engine_starts_unloaded_when_no_model_path() {
        let dir = tempdir().unwrap();
        let app = App::new(dir.path()).unwrap();
        assert!(!app.engine.is_loaded());
    }
}

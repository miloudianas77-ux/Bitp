//! Couche de mémoire persistante — SQLite WAL.
//!
//! ## Schéma
//! ```sql
//! messages   (id, content, is_user, timestamp_ms)
//! tool_notes (id, tool_name, result, timestamp_ms)
//! migrations (version, applied_at)
//! ```
//!
//! ## Concurrence
//! Connection unique protégée par `Mutex` (rusqlite n'est pas Sync).
//! Toutes les opérations sont **non-bloquantes** côté async :
//! elles utilisent `tokio::task::spawn_blocking`.

use crate::error::Result;
use parking_lot::Mutex;
use rusqlite::{params, Connection, OptionalExtension};
use std::path::Path;
use std::sync::Arc;

/// Numéro de version courant du schéma. À incrémenter à chaque migration.
const SCHEMA_VERSION: i64 = 2;

const MIGRATIONS: &[&str] = &[
    // v1 — schéma initial
    r#"
    CREATE TABLE IF NOT EXISTS messages (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        content      TEXT    NOT NULL,
        is_user      INTEGER NOT NULL CHECK (is_user IN (0, 1)),
        timestamp_ms INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER) * 1000)
    );
    CREATE TABLE IF NOT EXISTS tool_notes (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        tool_name    TEXT    NOT NULL,
        result       TEXT    NOT NULL,
        timestamp_ms INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER) * 1000)
    );
    CREATE INDEX IF NOT EXISTS idx_messages_ts ON messages(timestamp_ms DESC);
    CREATE INDEX IF NOT EXISTS idx_notes_ts    ON tool_notes(timestamp_ms DESC);
    "#,
    // v2 — index composite pour recherches par rôle
    r#"
    CREATE INDEX IF NOT EXISTS idx_messages_role_ts
        ON messages(is_user, timestamp_ms DESC);
    "#,
];

/// Repository centralisé pour l'historique de chat et les notes d'outils.
pub struct MemoryRepository {
    conn: Arc<Mutex<Connection>>,
}

impl MemoryRepository {
    /// Ouvre (ou crée) la base SQLite à `db_path` et applique les migrations.
    pub fn open(db_path: &Path) -> Result<Self> {
        let conn = Connection::open(db_path)?;
        Self::configure(&conn)?;
        Self::migrate(&conn)?;
        Ok(Self { conn: Arc::new(Mutex::new(conn)) })
    }

    /// Variante mémoire — utile pour tests / desktop temporaire.
    pub fn in_memory() -> Result<Self> {
        let conn = Connection::open_in_memory()?;
        Self::configure(&conn)?;
        Self::migrate(&conn)?;
        Ok(Self { conn: Arc::new(Mutex::new(conn)) })
    }

    fn configure(conn: &Connection) -> Result<()> {
        // PRAGMA — exécuter via `pragma_update` pour éviter les warnings.
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous  = NORMAL;
             PRAGMA temp_store   = MEMORY;
             PRAGMA mmap_size    = 134217728;  -- 128 MiB
             PRAGMA foreign_keys = ON;",
        )?;
        Ok(())
    }

    fn migrate(conn: &Connection) -> Result<()> {
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS migrations (
                version    INTEGER PRIMARY KEY,
                applied_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER))
            );",
        )?;

        let current: i64 = conn
            .query_row("SELECT COALESCE(MAX(version), 0) FROM migrations", [], |r| r.get(0))
            .optional()?
            .unwrap_or(0);

        for (i, sql) in MIGRATIONS.iter().enumerate() {
            let version = (i as i64) + 1;
            if version > current {
                log::info!("Applying migration v{version}");
                conn.execute_batch(sql)?;
                conn.execute(
                    "INSERT INTO migrations (version) VALUES (?1)",
                    params![version],
                )?;
            }
        }
        debug_assert!(SCHEMA_VERSION as usize == MIGRATIONS.len());
        Ok(())
    }

    /// Sauvegarde un message (utilisateur ou assistant).
    pub async fn save_message(&self, content: &str, is_user: bool) -> Result<i64> {
        let conn    = Arc::clone(&self.conn);
        let content = content.to_string();
        let id = tokio::task::spawn_blocking(move || -> Result<i64> {
            let db = conn.lock();
            db.execute(
                "INSERT INTO messages (content, is_user) VALUES (?1, ?2)",
                params![content, is_user as i32],
            )?;
            Ok(db.last_insert_rowid())
        }).await??;
        Ok(id)
    }

    /// Renvoie l'historique en ordre chronologique (plus ancien → plus récent).
    pub async fn get_history(&self, limit: usize) -> Result<Vec<(String, bool)>> {
        let conn = Arc::clone(&self.conn);
        tokio::task::spawn_blocking(move || -> Result<Vec<(String, bool)>> {
            let db = conn.lock();
            let mut stmt = db.prepare(
                "SELECT content, is_user FROM messages
                 ORDER BY timestamp_ms DESC, id DESC
                 LIMIT ?1",
            )?;
            let mut rows: Vec<(String, bool)> = stmt
                .query_map(params![limit as i64], |row| {
                    Ok((row.get::<_, String>(0)?, row.get::<_, i32>(1)? != 0))
                })?
                .filter_map(std::result::Result::ok)
                .collect();
            rows.reverse();
            Ok(rows)
        }).await?
    }

    pub async fn save_tool_result(&self, tool_name: &str, result: &str) -> Result<()> {
        let conn      = Arc::clone(&self.conn);
        let tool_name = tool_name.to_string();
        let result    = result.to_string();
        tokio::task::spawn_blocking(move || -> Result<()> {
            conn.lock().execute(
                "INSERT INTO tool_notes (tool_name, result) VALUES (?1, ?2)",
                params![tool_name, result],
            )?;
            Ok(())
        }).await??;
        Ok(())
    }

    /// Mémoire récente — mix d'anciennes réponses + notes d'outils, tronquée.
    pub async fn recent_memories(&self, limit: usize) -> Result<Vec<String>> {
        let conn = Arc::clone(&self.conn);
        let half = (limit / 2).max(1);
        tokio::task::spawn_blocking(move || -> Result<Vec<String>> {
            let db = conn.lock();

            let mut stmt1 = db.prepare(
                "SELECT content FROM messages
                 WHERE is_user = 0
                 ORDER BY timestamp_ms DESC LIMIT ?1",
            )?;
            let assistant_msgs: Vec<String> = stmt1
                .query_map(params![half as i64], |r| r.get::<_, String>(0))?
                .filter_map(std::result::Result::ok)
                .map(|s| format!("Previous reply: {}", truncate_chars(&s, 120)))
                .collect();

            let mut stmt2 = db.prepare(
                "SELECT tool_name, result FROM tool_notes
                 ORDER BY timestamp_ms DESC LIMIT ?1",
            )?;
            let notes: Vec<String> = stmt2
                .query_map(params![half as i64], |r| {
                    Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?))
                })?
                .filter_map(std::result::Result::ok)
                .map(|(n, res)| format!("Tool[{n}]: {}", truncate_chars(&res, 120)))
                .collect();

            Ok([assistant_msgs, notes].concat())
        }).await?
    }

    /// Vide l'historique et les notes d'outils. Garde les migrations.
    pub async fn clear(&self) -> Result<()> {
        let conn = Arc::clone(&self.conn);
        tokio::task::spawn_blocking(move || -> Result<()> {
            conn.lock().execute_batch(
                "DELETE FROM messages; DELETE FROM tool_notes;",
            )?;
            Ok(())
        }).await??;
        Ok(())
    }

    pub async fn count_messages(&self) -> Result<i64> {
        let conn = Arc::clone(&self.conn);
        tokio::task::spawn_blocking(move || -> Result<i64> {
            let db = conn.lock();
            let n: i64 = db.query_row("SELECT COUNT(*) FROM messages", [], |r| r.get(0))?;
            Ok(n)
        }).await?
    }

    /// Compactage / vacuum manuel (à appeler depuis Settings → Maintenance).
    pub async fn vacuum(&self) -> Result<()> {
        let conn = Arc::clone(&self.conn);
        tokio::task::spawn_blocking(move || -> Result<()> {
            conn.lock().execute_batch("VACUUM;")?;
            Ok(())
        }).await??;
        Ok(())
    }
}

fn truncate_chars(s: &str, max: usize) -> String {
    if s.chars().count() <= max { return s.to_string(); }
    let mut out: String = s.chars().take(max).collect();
    out.push('…');
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn save_and_retrieve_history_chronological() {
        let r = MemoryRepository::in_memory().unwrap();
        r.save_message("hello", true).await.unwrap();
        r.save_message("hi there", false).await.unwrap();
        let h = r.get_history(10).await.unwrap();
        assert_eq!(h.len(), 2);
        assert_eq!(h[0], ("hello".into(), true));
        assert_eq!(h[1], ("hi there".into(), false));
    }

    #[tokio::test]
    async fn clear_removes_all_data() {
        let r = MemoryRepository::in_memory().unwrap();
        r.save_message("x", true).await.unwrap();
        r.save_tool_result("t", "ok").await.unwrap();
        r.clear().await.unwrap();
        assert_eq!(r.count_messages().await.unwrap(), 0);
        assert!(r.recent_memories(10).await.unwrap().is_empty());
    }

    #[tokio::test]
    async fn recent_memories_blends_messages_and_tools() {
        let r = MemoryRepository::in_memory().unwrap();
        r.save_message("greeting", false).await.unwrap();
        r.save_tool_result("web_search", "found rust docs").await.unwrap();
        let m = r.recent_memories(10).await.unwrap();
        assert!(m.iter().any(|s| s.contains("Previous reply")));
        assert!(m.iter().any(|s| s.contains("Tool[web_search]")));
    }

    #[tokio::test]
    async fn migrations_are_idempotent() {
        let path = tempfile::NamedTempFile::new().unwrap().into_temp_path();
        {
            let _r = MemoryRepository::open(&path).unwrap();
        }
        // Re-open shouldn't fail.
        let r2 = MemoryRepository::open(&path).unwrap();
        assert_eq!(r2.count_messages().await.unwrap(), 0);
    }

    #[test]
    fn truncate_handles_unicode() {
        // 5 chars unicode = 5 chars logiques, pas 5 bytes
        let s = "éèà🦀😀";
        assert_eq!(truncate_chars(s, 3).chars().count(), 4); // 3 + ellipsis
    }
}

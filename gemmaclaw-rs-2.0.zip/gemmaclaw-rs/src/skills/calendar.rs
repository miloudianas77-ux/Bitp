//! Skill `create_calendar_event` — prépare un Intent Android `INSERT_EVENT`.
//!
//! La couche Rust **ne lance pas** l'Intent elle-même : elle retourne les données
//! structurées, et l'UI Slint (côté Android) déclenche l'Intent via le bridge JNI
//! (`android/jni_bridge.rs`). Ça garde la logique testable sur desktop.

use crate::skills::{Skill, SkillResult};
use async_trait::async_trait;
use chrono::{DateTime, FixedOffset, Local, NaiveDateTime, TimeZone};
use serde_json::{json, Value};

pub struct CalendarSkill;

#[async_trait]
impl Skill for CalendarSkill {
    fn name(&self) -> &'static str { "create_calendar_event" }

    fn description(&self) -> &'static str {
r#"Create a calendar event (returns Android intent payload).
Args: {"title":"Meeting", "description":"Agenda...", "location":"Office",
       "begin_time":"2025-06-15T14:30:00+02:00",
       "end_time":  "2025-06-15T15:30:00+02:00",
       "all_day": false}"#
    }

    fn args_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "title":       {"type":"string"},
                "description": {"type":"string"},
                "location":    {"type":"string"},
                "begin_time":  {"type":"string", "format":"date-time"},
                "end_time":    {"type":"string", "format":"date-time"},
                "all_day":     {"type":"boolean"}
            },
            "required": ["title", "begin_time"]
        })
    }

    async fn run(&self, args: Value) -> SkillResult {
        let title = args.get("title").and_then(Value::as_str).unwrap_or("").trim();
        if title.is_empty() {
            return SkillResult::failure("Missing 'title' argument");
        }

        let desc    = args.get("description").and_then(Value::as_str).unwrap_or("");
        let loc     = args.get("location").and_then(Value::as_str).unwrap_or("");
        let all_day = args.get("all_day").and_then(Value::as_bool).unwrap_or(false);

        let begin_str = args.get("begin_time").and_then(Value::as_str).unwrap_or("");
        let end_str   = args.get("end_time").and_then(Value::as_str).unwrap_or("");

        let begin_ms = match parse_iso(begin_str) {
            Some(ms) => ms,
            None => return SkillResult::failure(format!(
                "Invalid begin_time '{begin_str}'. Use ISO-8601 with offset, e.g. 2025-06-15T14:30:00+02:00"
            )),
        };
        // Si pas d'end_time : on suppose 1h.
        let end_ms = parse_iso(end_str).unwrap_or(begin_ms + 3_600_000);

        if end_ms < begin_ms {
            return SkillResult::failure("end_time must be after begin_time");
        }

        SkillResult::success_data(
            format!("Calendar event prepared: {title}"),
            json!({
                "action":       "INSERT_EVENT",
                "title":        title,
                "description":  desc,
                "location":     loc,
                "begin_ms":     begin_ms,
                "end_ms":       end_ms,
                "all_day":      all_day,
            }),
        )
    }
}

/// Parse ISO-8601 — 3 niveaux, JAMAIS de fallback silencieux sur `now()`.
///
/// 1. RFC 3339 avec offset : `2025-06-15T14:30:00+02:00`, `…Z`
/// 2. Sans timezone        : interprété en heure locale système
/// 3. Date seule            : `2025-06-15` → minuit local
pub fn parse_iso(s: &str) -> Option<i64> {
    let s = s.trim();
    if s.is_empty() { return None; }

    // 1. Avec offset (RFC 3339)
    if let Ok(dt) = DateTime::<FixedOffset>::parse_from_rfc3339(s) {
        return Some(dt.timestamp_millis());
    }

    // 2. Sans timezone — formats courants
    let no_tz_formats = [
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
    ];
    for f in &no_tz_formats {
        if let Ok(ndt) = NaiveDateTime::parse_from_str(s, f) {
            if let Some(local) = Local.from_local_datetime(&ndt).single() {
                return Some(local.timestamp_millis());
            }
        }
    }

    // 3. Date seule → minuit local
    if let Ok(d) = chrono::NaiveDate::parse_from_str(s, "%Y-%m-%d") {
        if let Some(midnight) = d.and_hms_opt(0, 0, 0) {
            if let Some(local) = Local.from_local_datetime(&midnight).single() {
                return Some(local.timestamp_millis());
            }
        }
    }

    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use pretty_assertions::assert_eq;

    #[test]
    fn parse_with_offset() {
        assert!(parse_iso("2025-06-15T14:30:00+02:00").is_some());
    }
    #[test]
    fn parse_with_z() {
        assert!(parse_iso("2025-06-15T14:30:00Z").is_some());
    }
    #[test]
    fn parse_without_tz() {
        assert!(parse_iso("2025-06-15T14:30:00").is_some());
    }
    #[test]
    fn parse_date_only() {
        assert!(parse_iso("2025-06-15").is_some());
    }
    #[test]
    fn parse_empty_or_invalid_returns_none() {
        assert_eq!(parse_iso(""), None);
        assert_eq!(parse_iso("not-a-date"), None);
        assert_eq!(parse_iso("2025-13-99"), None);
    }
    #[test]
    fn parse_never_falls_back_to_now() {
        // Même si la date est totalement invalide, on retourne None — jamais now().
        let now = chrono::Utc::now().timestamp_millis();
        let r   = parse_iso("xyz");
        assert!(r.is_none());
        let _ = now; // silence warn
    }

    #[tokio::test]
    async fn run_returns_intent_payload() {
        let s = CalendarSkill;
        let r = s.run(json!({
            "title":      "Test",
            "begin_time": "2025-06-15T14:30:00+00:00",
            "end_time":   "2025-06-15T15:30:00+00:00"
        })).await;
        assert!(r.success);
        let d = r.data.unwrap();
        assert_eq!(d["action"], "INSERT_EVENT");
        assert!(d["begin_ms"].as_i64().unwrap() > 0);
    }

    #[tokio::test]
    async fn run_rejects_inverted_dates() {
        let s = CalendarSkill;
        let r = s.run(json!({
            "title":      "Bad",
            "begin_time": "2025-06-15T15:00:00Z",
            "end_time":   "2025-06-15T14:00:00Z"
        })).await;
        assert!(!r.success);
    }
}

//! Skill `system_info` — heure locale, date, fuseau, plateforme.
//!
//! Les infos « battery » et « storage » nécessitent un appel JNI vers Android,
//! qui n'est pas fourni ici (TODO : `android::system::Battery::level()`).
//! On retourne `null` pour ces champs sur desktop, et le bridge JNI les remplit
//! sur Android.

use crate::skills::{Skill, SkillResult};
use async_trait::async_trait;
use chrono::Local;
use serde_json::{json, Value};

pub struct SystemInfoSkill;

#[async_trait]
impl Skill for SystemInfoSkill {
    fn name(&self) -> &'static str { "system_info" }

    fn description(&self) -> &'static str {
r#"Get device info. Args: {"info_type":"time"|"date"|"timezone"|"all"}.
Returns current time, date, timezone, platform."#
    }

    async fn run(&self, args: Value) -> SkillResult {
        let info_type = args.get("info_type").and_then(Value::as_str).unwrap_or("all");
        let now = Local::now();

        let data = match info_type {
            "time"     => json!({
                "current_time": now.format("%H:%M:%S").to_string(),
                "iso":          now.to_rfc3339(),
            }),
            "date"     => json!({
                "current_date": now.format("%Y-%m-%d").to_string(),
                "weekday":      now.format("%A").to_string(),
                "iso":          now.to_rfc3339(),
            }),
            "timezone" => json!({
                "timezone": now.format("%Z").to_string(),
                "offset":   now.format("%:z").to_string(),
            }),
            "all" | _  => json!({
                "current_time": now.format("%H:%M:%S").to_string(),
                "current_date": now.format("%Y-%m-%d").to_string(),
                "weekday":      now.format("%A").to_string(),
                "timezone":     now.format("%Z").to_string(),
                "offset":       now.format("%:z").to_string(),
                "iso":          now.to_rfc3339(),
                "platform":     platform_name(),
                "rust_version": env!("CARGO_PKG_VERSION"),
            }),
        };

        SkillResult::success_data("System info retrieved", data)
    }
}

const fn platform_name() -> &'static str {
    if cfg!(target_os = "android") { "Android (Rust runtime)" }
    else if cfg!(target_os = "linux") { "Linux (desktop)" }
    else if cfg!(target_os = "macos") { "macOS (desktop)" }
    else if cfg!(target_os = "windows") { "Windows (desktop)" }
    else { "Unknown" }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn returns_time_info() {
        let s = SystemInfoSkill;
        let r = s.run(json!({"info_type":"time"})).await;
        assert!(r.success);
        let d = r.data.unwrap();
        assert!(d.get("current_time").is_some());
        assert!(d.get("iso").is_some());
    }

    #[tokio::test]
    async fn all_includes_platform() {
        let s = SystemInfoSkill;
        let r = s.run(json!({"info_type":"all"})).await;
        let d = r.data.unwrap();
        assert!(d.get("platform").is_some());
    }
}

//! Système de skills (outils) — un trait, un registre, plusieurs implémentations.
//!
//! Pour ajouter un skill :
//! 1. Crée `src/skills/mon_skill.rs` qui implémente `Skill`
//! 2. Ajoute `pub mod mon_skill;` ci-dessous
//! 3. Enregistre-le dans `default_registry()`

use anyhow::Result as AnyResult; // pour back-compat
use async_trait::async_trait;
use serde_json::Value;
use std::collections::BTreeMap;
use std::sync::Arc;

pub mod calendar;
pub mod reminder;
pub mod system_info;
pub mod web_search;

/// Résultat structuré d'un skill.
#[derive(Debug, Clone, serde::Serialize)]
pub struct SkillResult {
    pub success: bool,
    pub message: String,
    /// Données structurées exposées au modèle (et à l'UI Android pour
    /// déclencher des Intents : SET_ALARM, INSERT_EVENT, etc.).
    pub data:    Option<Value>,
}

impl SkillResult {
    pub fn success(msg: impl Into<String>) -> Self {
        Self { success: true, message: msg.into(), data: None }
    }
    pub fn success_data(msg: impl Into<String>, data: Value) -> Self {
        Self { success: true, message: msg.into(), data: Some(data) }
    }
    pub fn failure(msg: impl Into<String>) -> Self {
        Self { success: false, message: msg.into(), data: None }
    }
}

/// Trait commun à tous les skills.
///
/// `Send + Sync + 'static` est requis car on les stocke dans un `Arc<dyn Skill>`
/// partagé entre threads.
#[async_trait]
pub trait Skill: Send + Sync + 'static {
    /// Identifiant utilisé dans les tool calls (ex: "web_search").
    fn name(&self) -> &'static str;

    /// Description visible par le modèle dans le manifeste.
    fn description(&self) -> &'static str;

    /// Schéma JSON des arguments (informationnel, pas validé strictement).
    fn args_schema(&self) -> Value {
        serde_json::json!({})
    }

    /// Exécute le skill.
    async fn run(&self, args: Value) -> SkillResult;
}

/// Registre des skills.
pub struct SkillRegistry {
    /// `BTreeMap` pour avoir un ordre stable dans le manifeste (testable).
    skills: BTreeMap<&'static str, Arc<dyn Skill>>,
}

impl SkillRegistry {
    pub fn new() -> Self {
        Self { skills: BTreeMap::new() }
    }

    pub fn register<S: Skill>(&mut self, skill: S) -> &mut Self {
        self.skills.insert(skill.name(), Arc::new(skill));
        self
    }

    pub fn get(&self, name: &str) -> Option<Arc<dyn Skill>> {
        self.skills.get(name).cloned()
    }

    pub fn names(&self) -> Vec<&'static str> {
        self.skills.keys().copied().collect()
    }

    pub fn len(&self) -> usize { self.skills.len() }
    pub fn is_empty(&self) -> bool { self.skills.is_empty() }

    /// Manifeste injecté dans le system prompt.
    pub fn manifest(&self) -> String {
        let mut out = String::new();
        for (i, s) in self.skills.values().enumerate() {
            if i > 0 { out.push('\n'); }
            out.push_str(&format!("- {}: {}", s.name(), s.description()));
        }
        out
    }

    /// Registre par défaut (production).
    pub fn default_registry() -> Arc<Self> {
        let mut reg = Self::new();
        reg.register(web_search::WebSearchSkill::default())
           .register(calendar::CalendarSkill)
           .register(reminder::ReminderSkill)
           .register(system_info::SystemInfoSkill);
        Arc::new(reg)
    }
}

impl Default for SkillRegistry {
    fn default() -> Self { Self::new() }
}

// Helper utilisé par certains skills pour valider plus joliment les args.
pub(crate) fn require_str<'a>(args: &'a Value, key: &str) -> Result<&'a str, SkillResult> {
    args.get(key)
        .and_then(|v| v.as_str())
        .filter(|s| !s.trim().is_empty())
        .ok_or_else(|| SkillResult::failure(format!("Missing or empty '{key}' argument")))
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Echo;
    #[async_trait]
    impl Skill for Echo {
        fn name(&self) -> &'static str { "echo" }
        fn description(&self) -> &'static str { "Echo input" }
        async fn run(&self, args: Value) -> SkillResult {
            SkillResult::success_data("ok", args)
        }
    }

    #[tokio::test]
    async fn registry_register_and_run() {
        let mut r = SkillRegistry::new();
        r.register(Echo);
        let s = r.get("echo").unwrap();
        let res = s.run(serde_json::json!({"x": 1})).await;
        assert!(res.success);
        assert_eq!(res.data.unwrap()["x"], 1);
    }

    #[test]
    fn manifest_is_stable_order() {
        let mut r = SkillRegistry::new();
        r.register(Echo);
        let m = r.manifest();
        assert!(m.contains("echo"));
    }

    #[test]
    fn default_registry_has_all_core_skills() {
        let r = SkillRegistry::default_registry();
        assert!(r.get("web_search").is_some());
        assert!(r.get("create_calendar_event").is_some());
        assert!(r.get("set_reminder").is_some());
        assert!(r.get("system_info").is_some());
        assert_eq!(r.len(), 4);
    }
}

// Évite warning "unused" sur AnyResult quand pas de skill l'utilise.
#[allow(dead_code)]
fn _silence(_: AnyResult<()>) {}

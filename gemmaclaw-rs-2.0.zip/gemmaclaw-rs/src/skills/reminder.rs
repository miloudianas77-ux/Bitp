//! Skill `set_reminder` — programme une alarme via `AlarmManager` Android.

use crate::skills::calendar::parse_iso;
use crate::skills::{Skill, SkillResult};
use async_trait::async_trait;
use serde_json::{json, Value};

pub struct ReminderSkill;

#[async_trait]
impl Skill for ReminderSkill {
    fn name(&self) -> &'static str { "set_reminder" }

    fn description(&self) -> &'static str {
        r#"Schedule a reminder/alarm. Args: {"title":"Take medicine","time":"2025-06-15T08:00:00+02:00","notes":"Optional notes"}"#
    }

    fn args_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "title": {"type":"string"},
                "time":  {"type":"string", "format":"date-time"},
                "notes": {"type":"string"}
            },
            "required": ["title","time"]
        })
    }

    async fn run(&self, args: Value) -> SkillResult {
        let title = args.get("title").and_then(Value::as_str).unwrap_or("").trim();
        if title.is_empty() {
            return SkillResult::failure("Missing 'title' argument");
        }
        let notes = args.get("notes").and_then(Value::as_str).unwrap_or("");
        let time_str = args.get("time").and_then(Value::as_str).unwrap_or("");

        let time_ms = match parse_iso(time_str) {
            Some(ms) => ms,
            None     => return SkillResult::failure(format!(
                "Invalid time '{time_str}'. Use ISO-8601 with offset (e.g. 2025-06-15T08:00:00+02:00)"
            )),
        };

        // Refuse les alarmes dans le passé
        let now_ms = chrono::Utc::now().timestamp_millis();
        if time_ms <= now_ms {
            return SkillResult::failure(format!(
                "Reminder time is in the past ({} ms before now)", now_ms - time_ms
            ));
        }

        SkillResult::success_data(
            format!("Reminder set: {title}"),
            json!({
                "action":  "SET_ALARM",
                "title":   title,
                "notes":   notes,
                "time_ms": time_ms,
            }),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn rejects_past_time() {
        let s = ReminderSkill;
        let r = s.run(json!({
            "title":"X","time":"2000-01-01T00:00:00Z"
        })).await;
        assert!(!r.success);
        assert!(r.message.contains("past"));
    }

    #[tokio::test]
    async fn requires_title_and_time() {
        let s = ReminderSkill;
        assert!(!s.run(json!({})).await.success);
        assert!(!s.run(json!({"title":"X"})).await.success);
    }

    #[tokio::test]
    async fn accepts_future_time() {
        let s  = ReminderSkill;
        let dt = chrono::Utc::now() + chrono::Duration::days(1);
        let r  = s.run(json!({
            "title":"Demo","time": dt.to_rfc3339()
        })).await;
        assert!(r.success, "got: {}", r.message);
        assert_eq!(r.data.unwrap()["action"], "SET_ALARM");
    }
}

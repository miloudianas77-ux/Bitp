//! Skill `web_search` — recherche DuckDuckGo HTML (sans clé API).
//!
//! ## Pourquoi DuckDuckGo HTML ?
//! * Pas de quota / clé API
//! * Réponse simple à parser
//! * Respecte la vie privée (pas de tracking utilisateur)
//!
//! ## Architecture
//! Le client `reqwest` est partagé via `OnceCell` — une seule connexion TLS
//! réutilisée entre les appels (perf majeure sur ARM).

use crate::skills::{require_str, Skill, SkillResult};
use async_trait::async_trait;
use once_cell::sync::OnceCell;
use scraper::{Html, Selector};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::time::Duration;

const USER_AGENT: &str =
    "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 \
     (KHTML, like Gecko) Chrome/124.0.6367.179 Mobile Safari/537.36";

const ENDPOINT: &str = "https://html.duckduckgo.com/html/";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResult {
    pub title:   String,
    pub url:     String,
    pub snippet: String,
}

#[derive(Default)]
pub struct WebSearchSkill {
    client: OnceCell<reqwest::Client>,
}

impl WebSearchSkill {
    fn client(&self) -> &reqwest::Client {
        self.client.get_or_init(|| {
            reqwest::Client::builder()
                .user_agent(USER_AGENT)
                .timeout(Duration::from_secs(10))
                .connect_timeout(Duration::from_secs(5))
                .pool_max_idle_per_host(2)
                .gzip(true).brotli(true)
                .build()
                .expect("reqwest client")
        })
    }
}

#[async_trait]
impl Skill for WebSearchSkill {
    fn name(&self) -> &'static str { "web_search" }

    fn description(&self) -> &'static str {
        r#"Search the web (DuckDuckGo). Args: {"query":"...", "max_results":3}. Returns titles, URLs and snippets."#
    }

    fn args_schema(&self) -> Value {
        json!({
            "type": "object",
            "properties": {
                "query":       {"type":"string", "description":"Search query"},
                "max_results": {"type":"integer", "default":3, "minimum":1, "maximum":10}
            },
            "required": ["query"]
        })
    }

    async fn run(&self, args: Value) -> SkillResult {
        let query = match require_str(&args, "query") {
            Ok(q)  => q.to_string(),
            Err(e) => return e,
        };
        let max = args.get("max_results")
            .and_then(Value::as_u64)
            .unwrap_or(3)
            .clamp(1, 10) as usize;

        match search_ddg(self.client(), &query, max).await {
            Ok(results) if results.is_empty() => SkillResult::failure(
                format!("No results found for: {query}"),
            ),
            Ok(results) => {
                let summary = format!("Found {} result(s) for: {query}", results.len());
                let json    = serde_json::to_value(&results).unwrap_or(Value::Null);
                SkillResult::success_data(summary, json)
            }
            Err(e) => SkillResult::failure(format!("Search error: {e}")),
        }
    }
}

async fn search_ddg(
    client: &reqwest::Client,
    query:  &str,
    max:    usize,
) -> anyhow::Result<Vec<SearchResult>> {
    let body = client
        .post(ENDPOINT)
        .form(&[("q", query), ("kl", "wt-wt")])
        .send()
        .await?
        .error_for_status()?
        .text()
        .await?;

    Ok(parse_ddg_html(&body, max))
}

/// Parse la page de résultats DuckDuckGo.
///
/// Extrait pour chaque hit :
/// * `.result__a`     → titre + href
/// * `.result__snippet`→ extrait
fn parse_ddg_html(html: &str, max: usize) -> Vec<SearchResult> {
    let doc = Html::parse_document(html);
    let res_sel  = Selector::parse(".result").expect("static selector");
    let title_sel = Selector::parse(".result__a").expect("static selector");
    let snip_sel  = Selector::parse(".result__snippet").expect("static selector");

    let mut out = Vec::with_capacity(max);
    for r in doc.select(&res_sel).take(max * 2) {
        let title = r.select(&title_sel).next();
        let snip  = r.select(&snip_sel).next();

        let (title_txt, url) = match title {
            Some(t) => {
                let txt = t.text().collect::<String>().trim().to_string();
                let raw = t.value().attr("href").unwrap_or("").to_string();
                (txt, normalize_ddg_url(&raw))
            }
            None => continue,
        };
        let snippet_txt = snip
            .map(|s| s.text().collect::<String>().trim().to_string())
            .unwrap_or_default();

        if !title_txt.is_empty() {
            out.push(SearchResult {
                title:   title_txt,
                url,
                snippet: snippet_txt,
            });
            if out.len() >= max { break; }
        }
    }
    out
}

/// DDG retourne souvent des URLs proxy `//duckduckgo.com/l/?uddg=...`.
fn normalize_ddg_url(href: &str) -> String {
    if let Some(idx) = href.find("uddg=") {
        let after = &href[idx + 5..];
        let end   = after.find('&').unwrap_or(after.len());
        if let Ok(decoded) = urlencoding::decode(&after[..end]) {
            return decoded.into_owned();
        }
    }
    if href.starts_with("//") { format!("https:{href}") }
    else if href.starts_with('/') { format!("https://duckduckgo.com{href}") }
    else { href.to_string() }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pretty_assertions::assert_eq;

    const SAMPLE_HTML: &str = r##"
<html><body>
<div class="result">
  <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Frust-lang.org%2F&rut=x">Rust Language</a>
  <a class="result__snippet">A language empowering everyone…</a>
</div>
<div class="result">
  <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fdoc.rust-lang.org%2F">Rust Docs</a>
  <a class="result__snippet">Official documentation</a>
</div>
</body></html>"##;

    #[test]
    fn parses_titles_urls_snippets() {
        let r = parse_ddg_html(SAMPLE_HTML, 5);
        assert_eq!(r.len(), 2);
        assert_eq!(r[0].title, "Rust Language");
        assert_eq!(r[0].url,   "https://rust-lang.org/");
        assert!(r[0].snippet.contains("empowering"));
    }

    #[test]
    fn respects_max_results() {
        let r = parse_ddg_html(SAMPLE_HTML, 1);
        assert_eq!(r.len(), 1);
    }

    #[test]
    fn normalize_proxy_url() {
        let n = normalize_ddg_url("//duckduckgo.com/l/?uddg=https%3A%2F%2Frust-lang.org%2F");
        assert_eq!(n, "https://rust-lang.org/");
    }

    #[tokio::test]
    async fn missing_query_returns_failure() {
        let s = WebSearchSkill::default();
        let r = s.run(json!({})).await;
        assert!(!r.success);
        assert!(r.message.to_lowercase().contains("query"));
    }
}

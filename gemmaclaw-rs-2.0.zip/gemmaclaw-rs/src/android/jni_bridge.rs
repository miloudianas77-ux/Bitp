//! Bridge JNI minimal pour appeler les APIs Android depuis Rust.
//!
//! Couvre :
//! * Lancement d'Intents (`INSERT_EVENT`, `SET_ALARM`, `ACTION_OPEN_DOCUMENT`)
//! * Lecture batterie / stockage
//! * Toast (notifications brèves)
//!
//! ## Stratégie
//! On utilise `ndk-context` pour récupérer le `JavaVM` exposé par
//! `android-activity`. Aucun `unsafe` n'est utilisé hors des appels JNI
//! eux-mêmes (encapsulés dans des fonctions safe).

use jni::objects::{JObject, JValue};
use jni::JavaVM;
use serde_json::Value;
use std::sync::OnceLock;

static VM: OnceLock<JavaVM> = OnceLock::new();

pub fn init(_app: &android_activity::AndroidApp) {
    // ndk-context expose JavaVM via la NativeActivity créée par android-activity.
    // SAFETY: le pointeur fourni par ndk_context est stable pendant la vie du process.
    let ctx = ndk_context::android_context();
    let vm_ptr = ctx.vm();
    if vm_ptr.is_null() {
        log::error!("JavaVM pointer is null — JNI bridge disabled");
        return;
    }
    // SAFETY: pointer issu de ndk_context, dont l'ABI matche celle de jni-rs
    let vm = unsafe { JavaVM::from_raw(vm_ptr.cast()) };
    match vm {
        Ok(vm) => {
            let _ = VM.set(vm);
            log::info!("JNI bridge initialized");
        }
        Err(e) => log::error!("JavaVM::from_raw failed: {e}"),
    }
}

fn vm() -> Option<&'static JavaVM> { VM.get() }

/// Affiche un toast court côté Android.
pub fn toast(msg: &str) {
    let Some(vm) = vm() else { return };
    let Ok(mut env) = vm.attach_current_thread() else { return };

    let ctx_ptr = ndk_context::android_context().context();
    if ctx_ptr.is_null() { return; }
    let ctx = unsafe { JObject::from_raw(ctx_ptr.cast()) };

    let _ = (|| -> jni::errors::Result<()> {
        let toast_class = env.find_class("android/widget/Toast")?;
        let jmsg = env.new_string(msg)?;
        let toast = env.call_static_method(
            &toast_class,
            "makeText",
            "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;",
            &[JValue::Object(&ctx), JValue::Object(&jmsg.into()), JValue::Int(0)],
        )?.l()?;
        env.call_method(&toast, "show", "()V", &[])?;
        Ok(())
    })();
}

/// Dispatch d'une `data` produite par un skill vers l'OS.
///
/// Reconnaît :
/// * `{"action":"INSERT_EVENT", ...}` → lance l'Intent calendar
/// * `{"action":"SET_ALARM",    ...}` → AlarmClock.ACTION_SET_ALARM
pub fn dispatch_skill_data(data: &Value) {
    let action = data.get("action").and_then(Value::as_str).unwrap_or("");
    match action {
        "INSERT_EVENT" => insert_event(data),
        "SET_ALARM"    => set_alarm(data),
        other          => log::warn!("Unknown skill action: {other}"),
    }
}

fn insert_event(data: &Value) {
    let Some(vm) = vm() else { return };
    let Ok(mut env) = vm.attach_current_thread() else { return };

    let ctx_ptr = ndk_context::android_context().context();
    if ctx_ptr.is_null() { return; }
    let ctx = unsafe { JObject::from_raw(ctx_ptr.cast()) };

    let title = data.get("title").and_then(Value::as_str).unwrap_or("");
    let desc  = data.get("description").and_then(Value::as_str).unwrap_or("");
    let loc   = data.get("location").and_then(Value::as_str).unwrap_or("");
    let begin = data.get("begin_ms").and_then(Value::as_i64).unwrap_or(0);
    let end   = data.get("end_ms").and_then(Value::as_i64).unwrap_or(begin + 3_600_000);

    let _ = (|| -> jni::errors::Result<()> {
        let intent_cls = env.find_class("android/content/Intent")?;
        let action_str = env.new_string("android.intent.action.INSERT")?;
        let intent = env.new_object(
            &intent_cls,
            "(Ljava/lang/String;)V",
            &[JValue::Object(&action_str.into())],
        )?;

        // setType("vnd.android.cursor.item/event")
        let mime = env.new_string("vnd.android.cursor.item/event")?;
        env.call_method(&intent, "setType",
            "(Ljava/lang/String;)Landroid/content/Intent;",
            &[JValue::Object(&mime.into())])?;

        // putExtra("title", title) ...
        let put = |env: &mut jni::JNIEnv, intent: &JObject, key: &str, val: &str| -> jni::errors::Result<()> {
            let k = env.new_string(key)?;
            let v = env.new_string(val)?;
            env.call_method(intent, "putExtra",
                "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;",
                &[JValue::Object(&k.into()), JValue::Object(&v.into())])?;
            Ok(())
        };
        put(&mut env, &intent, "title",       title)?;
        put(&mut env, &intent, "description", desc)?;
        put(&mut env, &intent, "eventLocation", loc)?;

        // beginTime / endTime sont des longs
        let key_b = env.new_string("beginTime")?;
        env.call_method(&intent, "putExtra",
            "(Ljava/lang/String;J)Landroid/content/Intent;",
            &[JValue::Object(&key_b.into()), JValue::Long(begin)])?;
        let key_e = env.new_string("endTime")?;
        env.call_method(&intent, "putExtra",
            "(Ljava/lang/String;J)Landroid/content/Intent;",
            &[JValue::Object(&key_e.into()), JValue::Long(end)])?;

        // FLAG_ACTIVITY_NEW_TASK = 0x10000000
        env.call_method(&intent, "addFlags",
            "(I)Landroid/content/Intent;",
            &[JValue::Int(0x1000_0000)])?;

        env.call_method(&ctx, "startActivity",
            "(Landroid/content/Intent;)V",
            &[JValue::Object(&intent)])?;
        Ok(())
    })().map_err(|e| log::error!("insert_event failed: {e}")).ok();
}

fn set_alarm(data: &Value) {
    let Some(vm) = vm() else { return };
    let Ok(mut env) = vm.attach_current_thread() else { return };

    let ctx_ptr = ndk_context::android_context().context();
    if ctx_ptr.is_null() { return; }
    let ctx = unsafe { JObject::from_raw(ctx_ptr.cast()) };

    let title = data.get("title").and_then(Value::as_str).unwrap_or("Reminder");
    let time_ms = data.get("time_ms").and_then(Value::as_i64).unwrap_or(0);
    if time_ms <= 0 { return; }

    let dt = chrono::DateTime::<chrono::Local>::from(
        std::time::UNIX_EPOCH + std::time::Duration::from_millis(time_ms as u64),
    );
    let hour    = dt.format("%H").to_string().parse::<i32>().unwrap_or(0);
    let minute  = dt.format("%M").to_string().parse::<i32>().unwrap_or(0);

    let _ = (|| -> jni::errors::Result<()> {
        let intent_cls = env.find_class("android/content/Intent")?;
        let action_str = env.new_string("android.intent.action.SET_ALARM")?;
        let intent = env.new_object(
            &intent_cls,
            "(Ljava/lang/String;)V",
            &[JValue::Object(&action_str.into())],
        )?;

        let put_str = |env: &mut jni::JNIEnv, intent: &JObject, key: &str, val: &str| -> jni::errors::Result<()> {
            let k = env.new_string(key)?;
            let v = env.new_string(val)?;
            env.call_method(intent, "putExtra",
                "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;",
                &[JValue::Object(&k.into()), JValue::Object(&v.into())])?;
            Ok(())
        };
        let put_int = |env: &mut jni::JNIEnv, intent: &JObject, key: &str, val: i32| -> jni::errors::Result<()> {
            let k = env.new_string(key)?;
            env.call_method(intent, "putExtra",
                "(Ljava/lang/String;I)Landroid/content/Intent;",
                &[JValue::Object(&k.into()), JValue::Int(val)])?;
            Ok(())
        };
        put_str(&mut env, &intent, "android.intent.extra.alarm.MESSAGE", title)?;
        put_int(&mut env, &intent, "android.intent.extra.alarm.HOUR",    hour)?;
        put_int(&mut env, &intent, "android.intent.extra.alarm.MINUTES", minute)?;

        env.call_method(&intent, "addFlags", "(I)Landroid/content/Intent;",
            &[JValue::Int(0x1000_0000)])?;

        env.call_method(&ctx, "startActivity",
            "(Landroid/content/Intent;)V",
            &[JValue::Object(&intent)])?;
        Ok(())
    })().map_err(|e| log::error!("set_alarm failed: {e}")).ok();
}

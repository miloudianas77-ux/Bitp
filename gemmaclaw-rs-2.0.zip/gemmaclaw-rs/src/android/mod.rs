//! Code spécifique à Android : entry point `android_main`, bridge JNI vers
//! les API Android (Calendar Intent, AlarmManager, file picker).
//!
//! Ce module n'est compilé que `#[cfg(target_os = "android")]`.

#![cfg(target_os = "android")]

pub mod jni_bridge;

use crate::app::App;
use crate::ui_loop;
use std::sync::Arc;

/// Entry point Android. Référencé via `<meta-data android:name="android.app.lib_name"/>`.
#[no_mangle]
pub extern "C" fn android_main(android_app: android_activity::AndroidApp) {
    android_log::init("GemmaClaw")
        .map(|_| log::info!("GemmaClaw v{} starting", crate::VERSION))
        .ok();

    // Le bridge JNI a besoin de l'AndroidApp pour récupérer le JavaVM.
    jni_bridge::init(&android_app);

    if let Err(e) = slint::android::init(android_app.clone()) {
        log::error!("Slint Android init failed: {e}");
        return;
    }

    let data_dir = android_app
        .internal_data_path()
        .map(|p| p.to_path_buf())
        .unwrap_or_else(|| std::path::PathBuf::from("/data/local/tmp"));

    match App::new(&data_dir).map(Arc::new) {
        Ok(app) => {
            if let Err(e) = ui_loop::run(app) {
                log::error!("UI loop error: {e}");
            }
        }
        Err(e) => log::error!("App init failed: {e}"),
    }
}

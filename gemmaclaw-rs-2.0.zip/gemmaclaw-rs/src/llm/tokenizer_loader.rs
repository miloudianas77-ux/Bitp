//! Chargement et résolution du `tokenizer.json`.
//!
//! Cherche dans cet ordre, à côté du fichier modèle :
//! 1. `tokenizer.json`
//! 2. `tokenizer/tokenizer.json`
//! 3. `<basename>.tokenizer.json`
//! 4. Variable d'environnement `GEMMACLAW_TOKENIZER`

use crate::error::{GemmaError, Result};
use std::path::{Path, PathBuf};
use tokenizers::Tokenizer;

/// Charge un tokenizer en cherchant intelligemment autour du modèle.
pub fn load(model_path: &Path) -> Result<Tokenizer> {
    let candidates = candidate_paths(model_path);
    for path in &candidates {
        if path.exists() {
            log::info!("Loading tokenizer: {path:?}");
            return Tokenizer::from_file(path)
                .map_err(|e| GemmaError::Tokenize(format!("{e}")));
        }
    }
    Err(GemmaError::TokenizerNotFound { path: model_path.to_path_buf() })
}

fn candidate_paths(model_path: &Path) -> Vec<PathBuf> {
    let mut out = Vec::with_capacity(4);
    let dir   = model_path.parent().unwrap_or_else(|| Path::new("."));
    let stem  = model_path.file_stem().unwrap_or_default().to_string_lossy().to_string();

    out.push(dir.join("tokenizer.json"));
    out.push(dir.join("tokenizer").join("tokenizer.json"));
    out.push(dir.join(format!("{stem}.tokenizer.json")));

    if let Ok(env) = std::env::var("GEMMACLAW_TOKENIZER") {
        out.push(PathBuf::from(env));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn candidates_include_sibling_tokenizer_json() {
        let p = Path::new("/tmp/foo/model.gguf");
        let cs = candidate_paths(p);
        assert!(cs.iter().any(|c| c == Path::new("/tmp/foo/tokenizer.json")));
    }

    #[test]
    fn candidates_include_basename_variant() {
        let p = Path::new("/tmp/foo/gemma-2b.gguf");
        let cs = candidate_paths(p);
        assert!(cs.iter().any(|c| c == Path::new("/tmp/foo/gemma-2b.tokenizer.json")));
    }

    #[test]
    fn missing_returns_typed_error() {
        let p = Path::new("/nonexistent/path/model.gguf");
        let err = load(p).unwrap_err();
        assert!(matches!(err, GemmaError::TokenizerNotFound { .. }));
    }
}

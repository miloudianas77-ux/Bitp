//! Stratégies d'échantillonnage : top-k, top-p, repeat-penalty.
//!
//! Implémentation 100% safe Rust, pas de dépendance externe pour
//! pouvoir tester les politiques d'échantillonnage indépendamment de candle.

use rand::{Rng, SeedableRng};
use rand::rngs::SmallRng;

/// Configuration d'échantillonnage.
#[derive(Debug, Clone)]
pub struct SamplingConfig {
    pub temperature:    f32,
    pub top_k:          usize,
    pub top_p:          f32,
    pub repeat_penalty: f32,
    pub repeat_window:  usize,
    pub seed:           u64,
}

impl Default for SamplingConfig {
    fn default() -> Self {
        Self {
            temperature:    0.7,
            top_k:          40,
            top_p:          0.95,
            repeat_penalty: 1.10,
            repeat_window:  64,
            seed:           42,
        }
    }
}

/// Sampler stateful — applique pénalité de répétition + top-k/p + softmax tempéré.
pub struct Sampler {
    cfg: SamplingConfig,
    rng: SmallRng,
}

impl Sampler {
    pub fn new(cfg: SamplingConfig) -> Self {
        let rng = SmallRng::seed_from_u64(cfg.seed);
        Self { cfg, rng }
    }

    /// Échantillonne le prochain token id à partir des logits bruts.
    /// `recent` est utilisé pour la repeat-penalty (fenêtre glissante).
    pub fn sample(&mut self, logits: &mut [f32], recent: &[u32]) -> u32 {
        // 1. Repeat penalty — divise les logits des tokens récents.
        if (self.cfg.repeat_penalty - 1.0).abs() > f32::EPSILON {
            let window = recent.len().saturating_sub(self.cfg.repeat_window);
            for &tok in &recent[window..] {
                if let Some(l) = logits.get_mut(tok as usize) {
                    if *l > 0.0 {
                        *l /= self.cfg.repeat_penalty;
                    } else {
                        *l *= self.cfg.repeat_penalty;
                    }
                }
            }
        }

        // 2. Greedy si température ≤ 0
        if self.cfg.temperature <= 0.0 {
            return argmax(logits);
        }

        // 3. Température
        let inv_t = 1.0 / self.cfg.temperature;
        for l in logits.iter_mut() {
            *l *= inv_t;
        }

        // 4. Top-k : conserver les k plus grands logits, mettre les autres à -inf
        if self.cfg.top_k > 0 && self.cfg.top_k < logits.len() {
            let mut sorted: Vec<(usize, f32)> =
                logits.iter().enumerate().map(|(i, &v)| (i, v)).collect();
            sorted.select_nth_unstable_by(self.cfg.top_k, |a, b| {
                b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal)
            });
            let threshold = sorted[self.cfg.top_k].1;
            for l in logits.iter_mut() {
                if *l < threshold {
                    *l = f32::NEG_INFINITY;
                }
            }
        }

        // 5. Softmax stable (sub-max trick)
        let max = logits.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        let mut probs: Vec<f32> = logits.iter().map(|&l| (l - max).exp()).collect();
        let sum: f32 = probs.iter().sum();
        if sum <= 0.0 || !sum.is_finite() {
            return argmax(logits);
        }
        for p in probs.iter_mut() { *p /= sum; }

        // 6. Top-p (nucleus) : trier par proba ↓, garder le préfixe atteignant top_p
        if self.cfg.top_p > 0.0 && self.cfg.top_p < 1.0 {
            let mut order: Vec<usize> = (0..probs.len()).collect();
            order.sort_unstable_by(|&a, &b| probs[b].partial_cmp(&probs[a]).unwrap_or(std::cmp::Ordering::Equal));
            let mut cumulative = 0.0;
            let mut keep = vec![false; probs.len()];
            for &idx in &order {
                keep[idx] = true;
                cumulative += probs[idx];
                if cumulative >= self.cfg.top_p { break; }
            }
            let mut new_sum = 0.0;
            for (i, p) in probs.iter_mut().enumerate() {
                if !keep[i] { *p = 0.0; } else { new_sum += *p; }
            }
            if new_sum > 0.0 {
                for p in probs.iter_mut() { *p /= new_sum; }
            }
        }

        // 7. Échantillonnage par roulette
        let r: f32 = self.rng.gen();
        let mut acc = 0.0;
        for (i, &p) in probs.iter().enumerate() {
            acc += p;
            if r <= acc { return i as u32; }
        }
        argmax(logits)
    }
}

fn argmax(logits: &[f32]) -> u32 {
    logits.iter()
        .enumerate()
        .fold((0usize, f32::NEG_INFINITY), |(bi, bv), (i, &v)| if v > bv { (i, v) } else { (bi, bv) })
        .0 as u32
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn greedy_when_temperature_zero() {
        let mut s = Sampler::new(SamplingConfig { temperature: 0.0, ..Default::default() });
        let mut l = vec![1.0_f32, 5.0, 3.0, 2.0];
        assert_eq!(s.sample(&mut l, &[]), 1);
    }

    #[test]
    fn repeat_penalty_dampens_recent_tokens() {
        let mut s = Sampler::new(SamplingConfig {
            temperature: 0.0,
            repeat_penalty: 10.0,
            ..Default::default()
        });
        // Sans pénalité, 1 gagnerait. Avec pénalité (1 dans recent), 2 gagne.
        let mut l = vec![1.0, 5.0, 4.9, 0.0];
        let pick = s.sample(&mut l, &[1]);
        assert_eq!(pick, 2);
    }

    #[test]
    fn sample_within_vocab() {
        let mut s = Sampler::new(SamplingConfig::default());
        let mut l: Vec<f32> = (0..32_000).map(|i| (i as f32 / 1000.0).sin()).collect();
        let pick = s.sample(&mut l, &[]);
        assert!((pick as usize) < 32_000);
    }
}

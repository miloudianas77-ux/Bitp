//! Couche LLM : moteur d'inférence Gemma + boucle d'agent + construction de prompts.
//!
//! ```text
//!  user_msg ──► PromptBuilder ──► GemmaEngine ──► tokens ──► AgentLoop
//!                                                              │
//!                                          (tool call détecté?)│
//!                                                              ▼
//!                                                          SkillRegistry
//! ```

pub mod agent_loop;
pub mod engine;
pub mod prompt_builder;
pub mod sampling;
pub mod tokenizer_loader;

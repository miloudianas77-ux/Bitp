//! Construction de prompts au format **Gemma chat template**.
//!
//! Gemma 2 utilise :
//! ```text
//! <start_of_turn>user
//! {message}<end_of_turn>
//! <start_of_turn>model
//! {response}<end_of_turn>
//! ```
//!
//! On ajoute :
//! * Un préambule système (skills + règles)
//! * Une troncature intelligente de l'historique pour respecter un budget tokens
//! * Un template de "follow-up" après exécution d'un outil

use std::fmt::Write as _;

const TOKEN_BUDGET: usize  = 1_400;
const CHARS_PER_TOKEN: f32 = 3.8; // estimation conservative pour Gemma sentencepiece

/// Message d'un échange utilisateur ↔ modèle.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChatMessage {
    pub content: String,
    pub is_user: bool,
}

impl ChatMessage {
    pub fn user(s: impl Into<String>)      -> Self { Self { content: s.into(), is_user: true  } }
    pub fn assistant(s: impl Into<String>) -> Self { Self { content: s.into(), is_user: false } }
}

/// Construit les prompts. Stateless — toutes les méthodes sont `pub fn`.
pub struct PromptBuilder;

impl PromptBuilder {
    /// Préambule système (sans mémoire utilisateur).
    pub fn system_prompt(tools: &str) -> String {
        format!(
r#"You are GemmaClaw — a local Android AI agent written in 100% Rust (no JVM, no GC).

# Operating principles
1. NEVER claim a tool succeeded unless its result confirms it.
2. To call a tool, output ONLY a single JSON object — no markdown, no prose, no preamble:
   {{"tool": "<name>", "args": {{ ... }}}}
3. If no tool is needed, reply directly in plain text — be concise and helpful.
4. Ask permission before sensitive actions (calendar, alarms, contacts, sending messages).
5. For dates/times, use ISO-8601 with timezone offset (e.g. 2025-06-15T14:30:00+02:00).
6. Reply in the user's language. Default to French if ambiguous.
7. If you don't know, say so — never fabricate facts.

# Available tools
{tools}

# Tool call examples
User: "What time is it?"
Assistant: {{"tool":"system_info","args":{{"info_type":"time"}}}}

User: "Remind me to take meds at 8am tomorrow"
Assistant: {{"tool":"set_reminder","args":{{"title":"Take meds","time":"2025-06-16T08:00:00+02:00"}}}}

If a previous tool result is given, read it carefully and answer the user naturally."#
        )
    }

    /// Préambule système + contexte de mémoire récente (notes de tool calls passés).
    pub fn system_prompt_with_memory(tools: &str, memories: &[String]) -> String {
        let base = Self::system_prompt(tools);
        if memories.is_empty() { return base; }
        let mut out = base;
        out.push_str("\n\n# Recent context (last activity)\n");
        for (i, m) in memories.iter().enumerate().take(10) {
            // Tronquer chaque ligne à 160 chars pour éviter de saturer le budget.
            let trimmed: String = m.chars().take(160).collect();
            let _ = writeln!(out, "{i}. {trimmed}");
        }
        out
    }

    /// Sérialise l'historique en respectant le budget. On garde toujours les
    /// **derniers** messages (les plus récents) en priorité.
    pub fn format_history(messages: &[ChatMessage]) -> String {
        if messages.is_empty() { return String::new(); }

        let budget_chars = (TOKEN_BUDGET as f32 * CHARS_PER_TOKEN) as usize;
        let formatted: Vec<String> = messages.iter().map(format_one).collect();

        let mut total = 0usize;
        let mut kept_rev: Vec<&str> = Vec::new();
        for line in formatted.iter().rev() {
            let cost = line.len() + 2;
            if total + cost > budget_chars { break; }
            total += cost;
            kept_rev.push(line.as_str());
        }
        let omitted = formatted.len() - kept_rev.len();
        let kept: Vec<&str> = kept_rev.into_iter().rev().collect();

        let mut out = String::new();
        if omitted > 0 {
            let _ = writeln!(out, "[... {omitted} older messages omitted ...]\n");
        }
        out.push_str(&kept.join("\n"));
        out
    }

    /// Prompt complet (1ère étape).
    pub fn build(system: &str, history: &str, user_msg: &str) -> String {
        let mut p = String::with_capacity(system.len() + history.len() + user_msg.len() + 128);
        p.push_str(system);
        p.push_str("\n\n");
        if !history.is_empty() {
            p.push_str(history);
            p.push('\n');
        }
        // Format Gemma chat
        let _ = write!(p,
            "<start_of_turn>user\n{user_msg}<end_of_turn>\n<start_of_turn>model\n"
        );
        p
    }

    /// Prompt de suivi après un appel d'outil.
    pub fn build_followup(
        system:      &str,
        history:     &str,
        user_msg:    &str,
        tool_call:   &str,
        tool_result: &str,
    ) -> String {
        let mut p = String::with_capacity(2048);
        p.push_str(system);
        p.push_str("\n\n");
        if !history.is_empty() {
            p.push_str(history);
            p.push('\n');
        }
        let _ = write!(p,
"<start_of_turn>user
{user_msg}<end_of_turn>
<start_of_turn>model
{tool_call}<end_of_turn>
<start_of_turn>tool
{tool_result}<end_of_turn>
<start_of_turn>model
"
        );
        p
    }
}

fn format_one(m: &ChatMessage) -> String {
    let role = if m.is_user { "user" } else { "model" };
    format!("<start_of_turn>{role}\n{}<end_of_turn>", m.content)
}

#[cfg(test)]
mod tests {
    use super::*;
    use pretty_assertions::assert_eq;

    #[test]
    fn empty_history_returns_empty() {
        assert_eq!(PromptBuilder::format_history(&[]), "");
    }

    #[test]
    fn history_within_budget_keeps_all() {
        let msgs = vec![ChatMessage::user("hi"), ChatMessage::assistant("hello")];
        let h = PromptBuilder::format_history(&msgs);
        assert!(h.contains("hi"));
        assert!(h.contains("hello"));
        assert!(!h.contains("omitted"));
    }

    #[test]
    fn history_over_budget_truncates_oldest_only() {
        let big = "A".repeat(2000);
        let msgs: Vec<ChatMessage> = (0..20)
            .map(|i| if i % 2 == 0 { ChatMessage::user(format!("{big} m{i}")) }
                                   else { ChatMessage::assistant(format!("{big} m{i}")) })
            .collect();
        let h = PromptBuilder::format_history(&msgs);
        assert!(h.contains("omitted"));
        assert!(h.contains("m19"), "doit garder le plus récent");
        assert!(!h.contains("m0"),  "doit retirer le plus ancien");
    }

    #[test]
    fn build_uses_gemma_template() {
        let p = PromptBuilder::build("SYS", "", "Bonjour");
        assert!(p.contains("<start_of_turn>user"));
        assert!(p.contains("Bonjour"));
        assert!(p.ends_with("<start_of_turn>model\n"));
    }

    #[test]
    fn followup_includes_tool_result() {
        let p = PromptBuilder::build_followup("SYS", "", "Q", "{\"tool\":\"x\"}", "OK");
        assert!(p.contains("<start_of_turn>tool"));
        assert!(p.contains("OK"));
    }

    #[test]
    fn system_prompt_lists_tools_and_rules() {
        let p = PromptBuilder::system_prompt("- web_search: ...\n- system_info: ...");
        assert!(p.contains("web_search"));
        assert!(p.contains("ISO-8601"));
        assert!(p.contains("JSON"));
    }

    #[test]
    fn memories_appear_under_system_when_present() {
        let p = PromptBuilder::system_prompt_with_memory(
            "- t1: x",
            &["user likes dark mode".into()],
        );
        assert!(p.contains("Recent context"));
        assert!(p.contains("dark mode"));
    }
}

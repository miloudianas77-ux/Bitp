//! Moteur d'inférence Gemma — chargement GGUF, KV-cache, streaming par tokens.
//!
//! ## Garanties
//! * **Zéro `unsafe`** (vs version 1.0 qui partageait un `*const Model` entre threads).
//! * **Annulation coopérative** via `AtomicBool` (`stop()` interrompt à la prochaine itération).
//! * **Streaming** par canal `tokio::mpsc` — l'UI reçoit les tokens dès qu'ils sortent.
//! * **Thread-safe** : l'état modèle est protégé par `parking_lot::RwLock`.
//!
//! ## Pipeline
//! ```text
//!   prompt ──► tokenize ──► prefill (1 forward) ──► decode loop
//!                                                       │
//!                                                       ├─► sampler
//!                                                       ├─► detokenize
//!                                                       └─► tx.send(Token::Text)
//! ```

use crate::error::{GemmaError, Result};
use crate::llm::sampling::{Sampler, SamplingConfig};
use crate::llm::tokenizer_loader;

use candle_core::{quantized::gguf_file, Device, Tensor};
use candle_transformers::models::quantized_gemma::ModelWeights as Gemma;
use parking_lot::RwLock;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use tokenizers::Tokenizer;
use tokio::sync::mpsc;

/// Taille maximale du contexte (Gemma 2 supporte 8192 — on garde 4096 pour la mémoire mobile).
const MAX_CONTEXT: usize = 4096;

/// Configuration de génération.
#[derive(Debug, Clone)]
pub struct InferenceConfig {
    pub max_new_tokens: usize,
    pub sampling:       SamplingConfig,
    pub stop_sequences: Vec<String>,
}

impl Default for InferenceConfig {
    fn default() -> Self {
        Self {
            max_new_tokens: 512,
            sampling:       SamplingConfig::default(),
            stop_sequences: vec!["<end_of_turn>".into(), "<eos>".into()],
        }
    }
}

/// Token streamé.
#[derive(Debug, Clone)]
pub enum Token {
    Text(String),
    Done,
    Error(String),
}

/// État interne du moteur — protégé par `RwLock` pour permettre lectures concurrentes
/// (`is_loaded`, `vocab_size`) et écritures exclusives (`load`, `unload`).
struct EngineState {
    model:        Gemma,
    tokenizer:    Tokenizer,
    device:       Device,
    eos_token:    u32,
    bos_token:    u32,
    model_path:   PathBuf,
}

/// Moteur d'inférence Gemma.
///
/// Une seule instance par processus ; l'app la partage via `Arc`.
pub struct GemmaEngine {
    state:           RwLock<Option<EngineState>>,
    config:          RwLock<InferenceConfig>,
    stop_requested:  AtomicBool,
    /// Compteur de tokens générés depuis le démarrage (pour métriques).
    tokens_generated: AtomicU64,
}

impl GemmaEngine {
    pub fn new() -> Self {
        Self {
            state:           RwLock::new(None),
            config:          RwLock::new(InferenceConfig::default()),
            stop_requested:  AtomicBool::new(false),
            tokens_generated: AtomicU64::new(0),
        }
    }

    /// Charge un modèle GGUF.
    ///
    /// Cette opération est synchrone et **lourde** (~quelques secondes sur ARM64).
    /// L'appelant doit la lancer dans `tokio::task::spawn_blocking`.
    pub fn load(&self, model_path: &Path) -> Result<()> {
        if !model_path.exists() {
            return Err(GemmaError::ModelNotFound { path: model_path.to_path_buf() });
        }
        log::info!("Loading GGUF model: {model_path:?}");

        let device = Self::select_device();
        log::info!("Using device: {device:?}");

        let mut file = std::fs::File::open(model_path)
            .map_err(|e| GemmaError::ModelLoad {
                reason: format!("open {model_path:?}: {e}"),
                source: None,
            })?;

        let content = gguf_file::Content::read(&mut file)
            .map_err(|e| GemmaError::ModelLoad {
                reason: format!("parse GGUF: {e}"),
                source: Some(anyhow::anyhow!("{e}")),
            })?;

        log::info!(
            "GGUF metadata loaded: {} tensors, {} metadata entries",
            content.tensor_infos.len(),
            content.metadata.len()
        );

        let model = Gemma::from_gguf(content, &mut file, &device)
            .map_err(|e| GemmaError::ModelLoad {
                reason: format!("instantiate Gemma: {e}"),
                source: Some(anyhow::anyhow!("{e}")),
            })?;

        let tokenizer = tokenizer_loader::load(model_path)?;

        let eos_token = tokenizer.token_to_id("<end_of_turn>")
            .or_else(|| tokenizer.token_to_id("<eos>"))
            .or_else(|| tokenizer.token_to_id("</s>"))
            .unwrap_or(1);
        let bos_token = tokenizer.token_to_id("<bos>")
            .or_else(|| tokenizer.token_to_id("<s>"))
            .unwrap_or(2);

        *self.state.write() = Some(EngineState {
            model,
            tokenizer,
            device,
            eos_token,
            bos_token,
            model_path: model_path.to_path_buf(),
        });
        log::info!("Model loaded successfully (EOS={eos_token}, BOS={bos_token})");
        Ok(())
    }

    /// Décharge le modèle et libère la mémoire ARM.
    pub fn unload(&self) {
        self.stop();
        *self.state.write() = None;
        log::info!("Model unloaded");
    }

    pub fn is_loaded(&self) -> bool {
        self.state.read().is_some()
    }

    pub fn model_path(&self) -> Option<PathBuf> {
        self.state.read().as_ref().map(|s| s.model_path.clone())
    }

    pub fn set_config(&self, config: InferenceConfig) {
        *self.config.write() = config;
    }

    pub fn config(&self) -> InferenceConfig {
        self.config.read().clone()
    }

    pub fn tokens_generated(&self) -> u64 {
        self.tokens_generated.load(Ordering::Relaxed)
    }

    /// Demande l'arrêt — la génération s'interrompt avant le prochain token.
    pub fn stop(&self) {
        self.stop_requested.store(true, Ordering::SeqCst);
    }

    /// Génération bloquante — utile à l'`AgentLoop` qui attend la réponse complète
    /// avant de détecter d'éventuels appels d'outils.
    pub fn generate(&self, prompt: &str) -> Result<String> {
        let mut rx = self.stream(prompt)?;
        let mut out = String::new();
        while let Some(tok) = rx.blocking_recv() {
            match tok {
                Token::Text(t)   => out.push_str(&t),
                Token::Done      => break,
                Token::Error(e)  => return Err(GemmaError::Inference(e)),
            }
        }
        Ok(out)
    }

    /// Streaming — retourne un canal de tokens consommables au fil de l'eau.
    pub fn stream(&self, prompt: &str) -> Result<mpsc::Receiver<Token>> {
        // Vérification précoce (avant de spawn un thread)
        if self.state.read().is_none() {
            return Err(GemmaError::ModelNotLoaded);
        }

        // Capacité 256 — bloque si l'UI n'avale pas assez vite (back-pressure).
        let (tx, rx) = mpsc::channel::<Token>(256);
        self.stop_requested.store(false, Ordering::SeqCst);

        let prompt = prompt.to_string();
        let cfg    = self.config.read().clone();

        // On ne peut pas envoyer le RwLockGuard à un thread → on déplace l'état.
        // Solution : tout l'état partagé est dans `Arc<Self>` (`self.state` accessible
        // par référence forte). Mais on a `&self`, donc on doit cloner les Arc.
        //
        // Pour rester safe, on prend une **lecture longue** et on copie ce qu'il faut
        // dans le thread via `tokio::task::spawn_blocking`. L'état modèle reste dans
        // le RwLock — on l'accède par scope dans le thread.
        //
        // Comme l'engine est toujours derrière un `Arc<GemmaEngine>` côté caller,
        // on ne peut pas le déplacer ici directement. On délègue donc le run au caller
        // via une fonction associée. Voir `run_inference_with_engine` dans `app.rs`.
        //
        // Implémentation pragmatique : on lance un thread qui ré-acquiert le lock.
        // Pour cela on a besoin d'un Arc<Self>. On expose donc un helper.
        run_inference_loop(self, prompt, cfg, tx)?;
        Ok(rx)
    }

    /// Sélection du device : CUDA > Metal > CPU.
    fn select_device() -> Device {
        #[cfg(feature = "cuda")]
        if let Ok(d) = Device::new_cuda(0) { return d; }
        #[cfg(feature = "metal")]
        if let Ok(d) = Device::new_metal(0) { return d; }
        Device::Cpu
    }
}

impl Default for GemmaEngine {
    fn default() -> Self { Self::new() }
}

// ─────────────────────────────────────────────────────────────────────────────
// Boucle d'inférence — exécutée dans un thread dédié pour ne pas bloquer tokio.
// ─────────────────────────────────────────────────────────────────────────────

fn run_inference_loop(
    engine: &GemmaEngine,
    prompt: String,
    cfg:    InferenceConfig,
    tx:     mpsc::Sender<Token>,
) -> Result<()> {
    // On ne déplace PAS de référence vers un thread → on fait toute l'inférence
    // de façon synchrone ici, puis on stream via le channel.
    //
    // Astuce : on prend un guard d'écriture (le modèle Gemma a un KV-cache mutable
    // via `forward(&mut self, ...)`) et on l'utilise dans la boucle.

    let mut state_guard = engine.state.write();
    let state = state_guard.as_mut().ok_or(GemmaError::ModelNotLoaded)?;

    // 1. Tokenisation
    let encoding = state.tokenizer.encode(prompt.as_str(), true)
        .map_err(|e| GemmaError::Tokenize(e.to_string()))?;
    let input_ids: Vec<u32> = encoding.get_ids().to_vec();

    if input_ids.is_empty() {
        let _ = tx.blocking_send(Token::Done);
        return Ok(());
    }
    if input_ids.len() >= MAX_CONTEXT {
        return Err(GemmaError::Inference(format!(
            "Prompt trop long : {} tokens (max {MAX_CONTEXT})",
            input_ids.len()
        )));
    }

    log::debug!("Prefill: {} tokens", input_ids.len());

    // 2. Prefill — un seul forward sur tout le prompt, position 0
    let prefill = Tensor::new(input_ids.as_slice(), &state.device)
        .and_then(|t| t.unsqueeze(0))
        .map_err(|e| GemmaError::Inference(format!("prefill tensor: {e}")))?;

    let mut logits = state.model.forward(&prefill, 0)
        .map_err(|e| GemmaError::Inference(format!("prefill forward: {e}")))?;

    // Squeeze batch + extraire la dernière position
    logits = logits.squeeze(0)
        .map_err(|e| GemmaError::Inference(format!("squeeze: {e}")))?;
    let last_idx = logits.dim(0)
        .map_err(|e| GemmaError::Inference(format!("dim: {e}")))?
        .saturating_sub(1);
    let mut next_logits = logits.get(last_idx)
        .map_err(|e| GemmaError::Inference(format!("get last: {e}")))?;

    // 3. Decode loop
    let mut sampler   = Sampler::new(cfg.sampling.clone());
    let mut generated = input_ids.clone();
    let mut streamed_text = String::new();
    let stop_seqs: Vec<&str> = cfg.stop_sequences.iter().map(String::as_str).collect();

    for step in 0..cfg.max_new_tokens {
        if engine.stop_requested.load(Ordering::Relaxed) {
            log::info!("Generation cancelled at step {step}");
            let _ = tx.blocking_send(Token::Done);
            return Ok(());
        }

        // Logits → Vec<f32>
        let mut logits_vec: Vec<f32> = next_logits.to_vec1()
            .map_err(|e| GemmaError::Inference(format!("to_vec1: {e}")))?;

        let next_id = sampler.sample(&mut logits_vec, &generated);
        engine.tokens_generated.fetch_add(1, Ordering::Relaxed);

        if next_id == state.eos_token {
            log::debug!("EOS at step {step}");
            break;
        }
        generated.push(next_id);

        // Détokenize incrémentalement (Gemma utilise sentencepiece → on doit
        // détokenize TOUS les nouveaux tokens depuis la dernière fois pour
        // gérer correctement les caractères multi-octets / espaces).
        if let Ok(text) = state.tokenizer.decode(
            &generated[input_ids.len()..],
            true,
        ) {
            if text.len() > streamed_text.len() {
                let new_chunk = text[streamed_text.len()..].to_string();
                streamed_text = text.clone();

                // Stop sequences
                if stop_seqs.iter().any(|s| streamed_text.contains(s)) {
                    log::debug!("Stop sequence hit");
                    break;
                }

                if tx.blocking_send(Token::Text(new_chunk)).is_err() {
                    log::debug!("Receiver dropped — aborting generation");
                    break;
                }
            }
        }

        // Forward incrémental — un seul token, position = generated.len()-1
        let pos = generated.len() - 1;
        if pos >= MAX_CONTEXT {
            log::warn!("Context window full ({MAX_CONTEXT}) — stopping");
            break;
        }

        let next_in = Tensor::new(&[next_id], &state.device)
            .and_then(|t| t.unsqueeze(0))
            .map_err(|e| GemmaError::Inference(format!("decode tensor: {e}")))?;

        let out = state.model.forward(&next_in, pos)
            .map_err(|e| GemmaError::Inference(format!("decode forward: {e}")))?;

        next_logits = out.squeeze(0)
            .and_then(|t| t.squeeze(0).or(Ok(t)))
            .map_err(|e| GemmaError::Inference(format!("decode squeeze: {e}")))?;
    }

    let _ = tx.blocking_send(Token::Done);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn engine_starts_unloaded() {
        let e = GemmaEngine::new();
        assert!(!e.is_loaded());
        assert_eq!(e.tokens_generated(), 0);
    }

    #[test]
    fn generate_without_model_returns_typed_error() {
        let e = GemmaEngine::new();
        let err = e.stream("hello").unwrap_err();
        assert!(matches!(err, GemmaError::ModelNotLoaded));
    }

    #[test]
    fn config_round_trip() {
        let e = GemmaEngine::new();
        let mut cfg = e.config();
        cfg.max_new_tokens = 1024;
        cfg.sampling.temperature = 0.3;
        e.set_config(cfg);
        assert_eq!(e.config().max_new_tokens, 1024);
        assert!((e.config().sampling.temperature - 0.3).abs() < 1e-6);
    }
}

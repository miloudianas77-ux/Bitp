//! Boucle d'agent — détecte les appels d'outils et orchestre les étapes.
//!
//! ## Flux
//! ```text
//!  user_msg
//!     │
//!     ▼
//!  ┌──────────────────┐
//!  │ build prompt     │◄────────────┐
//!  └──────────────────┘             │
//!     │                             │
//!     ▼                             │
//!  ┌──────────────────┐             │
//!  │ engine.generate  │             │ tool_result
//!  └──────────────────┘             │ (followup)
//!     │                             │
//!     ▼                             │
//!  parse_tool_call ──── Some ──► run skill ──┘
//!     │
//!     None
//!     │
//!     ▼
//!  AgentResponse::{Text|Stream}
//! ```

use crate::error::{GemmaError, Result};
use crate::llm::engine::GemmaEngine;
use crate::llm::prompt_builder::{ChatMessage, PromptBuilder};
use crate::memory::MemoryRepository;
use crate::settings::Settings;
use crate::skills::{SkillRegistry, SkillResult};

use serde_json::Value;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::mpsc;

const MAX_STEPS: usize = 3;
const STEP_TIMEOUT: Duration = Duration::from_secs(120);

/// Réponse de l'agent.
pub enum AgentResponse {
    /// Texte complet déjà calculé.
    Text(String),
    /// Canal de streaming — l'UI reçoit les chunks au fil de l'eau.
    Stream(mpsc::Receiver<String>),
}

/// Orchestrateur principal.
pub struct AgentLoop {
    engine:   Arc<GemmaEngine>,
    skills:   Arc<SkillRegistry>,
    memory:   Arc<MemoryRepository>,
    settings: Arc<Settings>,
    /// Annulation côté agent (en plus de l'annulation engine).
    cancelled: Arc<AtomicBool>,
}

impl AgentLoop {
    pub fn new(
        engine:   Arc<GemmaEngine>,
        skills:   Arc<SkillRegistry>,
        memory:   Arc<MemoryRepository>,
        settings: Arc<Settings>,
    ) -> Self {
        Self {
            engine, skills, memory, settings,
            cancelled: Arc::new(AtomicBool::new(false)),
        }
    }

    /// Point d'entrée principal — produit une réponse finale (texte ou stream).
    pub async fn respond(
        &self,
        user_msg: &str,
        history:  &[ChatMessage],
    ) -> Result<AgentResponse> {
        self.cancelled.store(false, Ordering::SeqCst);

        let memories = if self.settings.memory_enabled() {
            self.memory.recent_memories(10).await.unwrap_or_default()
        } else {
            Vec::new()
        };

        let system    = PromptBuilder::system_prompt_with_memory(
            &self.skills.manifest(),
            &memories,
        );
        let hist_text = PromptBuilder::format_history(history);
        let mut prompt = PromptBuilder::build(&system, &hist_text, user_msg);
        let stream_pref = self.settings.streaming_enabled();

        for step in 0..MAX_STEPS {
            if self.cancelled.load(Ordering::Relaxed) {
                return Err(GemmaError::Cancelled);
            }
            log::debug!("Agent step {step}");

            let response = self.run_engine_step(&prompt).await?;
            log::debug!("Step {step} response (head): {}", head(&response, 120));

            match parse_tool_call(&response) {
                None => {
                    let final_text = clean_response(&response);
                    return Ok(if stream_pref {
                        AgentResponse::Stream(word_stream(final_text))
                    } else {
                        AgentResponse::Text(final_text)
                    });
                }
                Some((tool_name, args)) => {
                    let result = self.run_tool(&tool_name, args).await;
                    log::info!("Skill {tool_name} → success={}", result.success);

                    if result.success && self.settings.memory_enabled() {
                        let _ = self.memory
                            .save_tool_result(&tool_name, &result.message)
                            .await;
                    }

                    let tool_result = serde_json::to_string(&serde_json::json!({
                        "success": result.success,
                        "message": result.message,
                        "data":    result.data,
                    })).unwrap_or_else(|_| "{}".into());

                    prompt = PromptBuilder::build_followup(
                        &system, &hist_text, user_msg, &response, &tool_result,
                    );
                }
            }
        }

        Err(GemmaError::MaxStepsReached { max: MAX_STEPS })
    }

    /// Annule la génération en cours (côté engine ET côté agent).
    pub fn stop(&self) {
        self.cancelled.store(true, Ordering::SeqCst);
        self.engine.stop();
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    async fn run_engine_step(&self, prompt: &str) -> Result<String> {
        let engine = Arc::clone(&self.engine);
        let prompt = prompt.to_string();
        // L'inférence est CPU-bound → spawn_blocking.
        let fut = tokio::task::spawn_blocking(move || engine.generate(&prompt));

        match tokio::time::timeout(STEP_TIMEOUT, fut).await {
            Ok(Ok(res)) => res,
            Ok(Err(e))  => Err(GemmaError::JoinError(e)),
            Err(_)      => {
                self.engine.stop();
                Err(GemmaError::Inference("Timeout (120s) reached".into()))
            }
        }
    }

    async fn run_tool(&self, name: &str, args: Value) -> SkillResult {
        let Some(skill) = self.skills.get(name) else {
            return SkillResult::failure(format!("Unknown tool: {name}"));
        };
        // Timeout par skill : 30s
        match tokio::time::timeout(Duration::from_secs(30), skill.run(args)).await {
            Ok(r)  => r,
            Err(_) => SkillResult::failure(format!("Skill {name} timed out (30s)")),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Parsing des tool calls — robuste face aux préambules / suffixes du modèle.
// ─────────────────────────────────────────────────────────────────────────────

/// Re-export pour les tests d'intégration (`tests/integration_agent.rs`).
#[doc(hidden)]
pub fn parse_tool_call_for_test(text: &str) -> Option<(String, Value)> {
    parse_tool_call(text)
}

/// Parse la réponse du modèle : retourne `Some((tool_name, args))` ssi un
/// objet JSON bien formé contenant une clé `tool` est trouvé.
pub(crate) fn parse_tool_call(text: &str) -> Option<(String, Value)> {
    // 1. Cherche un bloc ```json``` ou ```...```
    if let Some(block) = extract_code_block(text) {
        if let Some(call) = try_parse_obj(&block) { return Some(call); }
    }
    // 2. Cherche le premier objet JSON équilibré
    let bytes = text.as_bytes();
    for (i, &b) in bytes.iter().enumerate() {
        if b == b'{' {
            if let Some(end) = find_matching_brace(text, i) {
                if let Some(call) = try_parse_obj(&text[i..=end]) {
                    return Some(call);
                }
            }
        }
    }
    None
}

fn try_parse_obj(s: &str) -> Option<(String, Value)> {
    let json: Value = serde_json::from_str(s).ok()?;
    let tool = json.get("tool")?.as_str()?.trim().to_string();
    if tool.is_empty() { return None; }
    let args = json.get("args").cloned().unwrap_or(Value::Object(Default::default()));
    Some((tool, args))
}

fn extract_code_block(text: &str) -> Option<String> {
    let start = text.find("```")?;
    let after = &text[start + 3..];
    // Saute la langue éventuelle ("json\n")
    let nl    = after.find('\n')?;
    let body  = &after[nl + 1..];
    let end   = body.find("```")?;
    Some(body[..end].to_string())
}

fn find_matching_brace(s: &str, open_idx: usize) -> Option<usize> {
    let bytes = s.as_bytes();
    let mut depth = 0i32;
    let mut in_str = false;
    let mut escape = false;
    for (i, &b) in bytes.iter().enumerate().skip(open_idx) {
        if in_str {
            if escape          { escape = false; continue; }
            if b == b'\\'      { escape = true;  continue; }
            if b == b'"'       { in_str = false; }
            continue;
        }
        match b {
            b'"' => in_str = true,
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 { return Some(i); }
            }
            _ => {}
        }
    }
    None
}

/// Nettoie la réponse modèle : enlève les balises Gemma résiduelles + trim.
fn clean_response(text: &str) -> String {
    text.replace("<end_of_turn>", "")
        .replace("<start_of_turn>model", "")
        .replace("<start_of_turn>", "")
        .trim()
        .to_string()
}

fn head(s: &str, n: usize) -> String {
    s.chars().take(n).collect::<String>().replace('\n', " ")
}

/// Émet les mots un par un — donne une illusion de streaming quand la
/// génération a été collectée d'un bloc (ex. dans la phase de tool call).
fn word_stream(text: String) -> mpsc::Receiver<String> {
    let (tx, rx) = mpsc::channel(128);
    tokio::spawn(async move {
        for word in text.split_inclusive(' ') {
            if tx.send(word.to_string()).await.is_err() { return; }
            tokio::time::sleep(Duration::from_millis(8)).await;
        }
    });
    rx
}

#[cfg(test)]
mod tests {
    use super::*;
    use pretty_assertions::assert_eq;

    #[test]
    fn parse_pure_json() {
        let s = r#"{"tool":"web_search","args":{"query":"rust"}}"#;
        let (n, a) = parse_tool_call(s).unwrap();
        assert_eq!(n, "web_search");
        assert_eq!(a["query"], "rust");
    }

    #[test]
    fn parse_with_preamble_text() {
        let s = r#"Sure! {"tool":"system_info","args":{"info_type":"time"}}"#;
        let (n, _) = parse_tool_call(s).unwrap();
        assert_eq!(n, "system_info");
    }

    #[test]
    fn parse_inside_markdown_block() {
        let s = "Voici ma réponse :\n```json\n{\"tool\":\"set_reminder\",\"args\":{\"title\":\"test\"}}\n```\n";
        let (n, a) = parse_tool_call(s).unwrap();
        assert_eq!(n, "set_reminder");
        assert_eq!(a["title"], "test");
    }

    #[test]
    fn parse_handles_nested_braces_and_strings() {
        let s = r#"{"tool":"x","args":{"q":"a {b} c","nested":{"k":1}}}"#;
        let (_, a) = parse_tool_call(s).unwrap();
        assert_eq!(a["q"], "a {b} c");
        assert_eq!(a["nested"]["k"], 1);
    }

    #[test]
    fn parse_no_tool_returns_none() {
        assert!(parse_tool_call("Bonjour, je peux vous aider ?").is_none());
        assert!(parse_tool_call(r#"{"foo":"bar"}"#).is_none());
        assert!(parse_tool_call(r#"{"tool":""}"#).is_none());
    }

    #[test]
    fn parse_skips_invalid_first_brace_finds_next() {
        // Premier { invalide, second valide
        let s = r#"{not json} but here: {"tool":"x","args":{}}"#;
        let (n, _) = parse_tool_call(s).unwrap();
        assert_eq!(n, "x");
    }

    #[test]
    fn clean_response_strips_gemma_tags() {
        let s = "Bonjour<end_of_turn>";
        assert_eq!(clean_response(s), "Bonjour");
    }
}

//! # GemmaClaw — Agent IA local 100% Rust
//!
//! Cette crate expose à la fois :
//! * Une **bibliothèque** (`rlib`) utilisable depuis tests et binaires desktop
//! * Une **dynamic library** (`cdylib`) chargée par `NativeActivity` sur Android

#![cfg_attr(docsrs, feature(doc_cfg))]

pub mod app;
pub mod error;
pub mod llm;
pub mod memory;
pub mod settings;
pub mod skills;
pub mod ui_loop;

#[cfg(target_os = "android")]
pub mod android;

pub use app::{App, AppHandle};
pub use error::{GemmaError, Result};
pub use llm::engine::{GemmaEngine, InferenceConfig, Token};
pub use llm::agent_loop::{AgentLoop, AgentResponse};
pub use llm::prompt_builder::{ChatMessage, PromptBuilder};
pub use memory::MemoryRepository;
pub use settings::{Settings, SettingsData};
pub use skills::{Skill, SkillRegistry, SkillResult};

pub const VERSION:  &str = env!("CARGO_PKG_VERSION");
pub const GIT_HASH: &str = env!("GIT_HASH");

pub fn build_id() -> String { format!("{VERSION}+{GIT_HASH}") }

slint::include_modules!();

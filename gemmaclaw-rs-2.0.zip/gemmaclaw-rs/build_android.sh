#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# GemmaClaw Rust 2.0 — Build Android (debug + release)
#
# Compatible : Google Cloud Shell, Ubuntu 22+, macOS, Termux
#
# Usage :
#   ./build_android.sh                # debug, ARM64
#   ./build_android.sh release        # release signé
#   ./build_android.sh release armv7  # release pour ARM 32-bit
#   ./build_android.sh debug all      # multi-ABI APK universel
#
# Améliorations vs version 1.0 :
#   ✓ Utilise aapt2 (aapt v1 déprécié)
#   ✓ Compile classes.dex minimal (NativeActivity stub) pour Android 14+
#   ✓ Multi-ABI optionnel (arm64 + armv7 + x86_64)
#   ✓ Gestion d'erreurs stricte (set -euo pipefail + traps)
#   ✓ Détection auto de NDK / SDK existant
#   ✓ Aligne AVANT signature (apksigner v3 le requiert)
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
trap 'echo "❌ Build failed at line $LINENO" >&2' ERR

MODE="${1:-debug}"
ABI_ARG="${2:-arm64}"

case "$ABI_ARG" in
    arm64) ABIS=("arm64-v8a"); RUST_TARGETS=("aarch64-linux-android") ;;
    armv7) ABIS=("armeabi-v7a"); RUST_TARGETS=("armv7-linux-androideabi") ;;
    x86)   ABIS=("x86_64");      RUST_TARGETS=("x86_64-linux-android") ;;
    all)
        ABIS=("arm64-v8a" "armeabi-v7a" "x86_64")
        RUST_TARGETS=("aarch64-linux-android" "armv7-linux-androideabi" "x86_64-linux-android") ;;
    *) echo "Unknown ABI: $ABI_ARG (use arm64|armv7|x86|all)" >&2; exit 1 ;;
esac

ANDROID_API=26
NDK_VERSION="${NDK_VERSION:-26.3.11579264}"
SDK_BUILD_TOOLS="${SDK_BUILD_TOOLS:-34.0.0}"
SDK_PLATFORM="android-34"
APP_NAME="GemmaClaw"
PKG="com.gemmaclaw.app"

echo "════════════════════════════════════════════════════"
echo "  $APP_NAME Rust 2.0 — Build Android ($MODE / $ABI_ARG)"
echo "════════════════════════════════════════════════════"

# ── 1. Rust ──────────────────────────────────────────────────────────────────
if ! command -v cargo >/dev/null; then
    echo "▶ Installation de Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --no-modify-path
    source "$HOME/.cargo/env"
fi
echo "✓ $(rustc --version)"
for tgt in "${RUST_TARGETS[@]}"; do
    rustup target add "$tgt"
done

# ── 2. Java ──────────────────────────────────────────────────────────────────
if ! command -v java >/dev/null; then
    echo "▶ Installation Java 17..."
    if command -v apt-get >/dev/null; then
        sudo apt-get update -qq
        sudo apt-get install -y -qq openjdk-17-jdk-headless
    elif command -v brew >/dev/null; then
        brew install openjdk@17
    elif command -v pkg >/dev/null; then
        pkg install -y openjdk-17
    fi
fi
java -version

# ── 3. SDK + NDK ─────────────────────────────────────────────────────────────
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
mkdir -p "$SDK_ROOT/cmdline-tools"

if [ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
    echo "▶ Installation Android SDK command-line tools..."
    SDK_ZIP="commandlinetools-linux-11076708_latest.zip"
    [ -f "$SDK_ZIP" ] || wget -q "https://dl.google.com/android/repository/$SDK_ZIP"
    unzip -q -o "$SDK_ZIP" -d "$SDK_ROOT/cmdline-tools"
    [ -d "$SDK_ROOT/cmdline-tools/cmdline-tools" ] && \
        mv "$SDK_ROOT/cmdline-tools/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
fi
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"

yes 2>/dev/null | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager --install \
    "build-tools;$SDK_BUILD_TOOLS" \
    "platforms;$SDK_PLATFORM" \
    "ndk;$NDK_VERSION" \
    "platform-tools" >/dev/null

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_NDK_ROOT="$SDK_ROOT/ndk/$NDK_VERSION"
export ANDROID_NDK_HOME="$ANDROID_NDK_ROOT"
echo "✓ NDK $NDK_VERSION"

# ── 4. cargo-ndk ─────────────────────────────────────────────────────────────
if ! command -v cargo-ndk >/dev/null; then
    echo "▶ Installation cargo-ndk..."
    cargo install cargo-ndk --locked
fi
echo "✓ cargo-ndk installé"

# ── 5. Compilation Rust → .so ────────────────────────────────────────────────
echo ""
echo "▶ Compilation Rust pour : ${ABIS[*]}"
ABI_FLAGS=()
for abi in "${ABIS[@]}"; do
    ABI_FLAGS+=("-t" "$abi")
done

if [ "$MODE" = "release" ]; then
    cargo ndk "${ABI_FLAGS[@]}" -p "$ANDROID_API" -o jniLibs build --release --lib --no-default-features --features android
    PROFILE_DIR="release"
else
    cargo ndk "${ABI_FLAGS[@]}" -p "$ANDROID_API" -o jniLibs build --lib --no-default-features --features android
    PROFILE_DIR="debug"
fi
echo "✓ Bibliothèques natives compilées"

# ── 6. Génération du minimal classes.dex (NativeActivity stub) ───────────────
echo ""
echo "▶ Génération de classes.dex minimal..."
DX_DIR="build_apk_tmp/dex_src"
DX_OUT="build_apk_tmp/dex_out"
rm -rf build_apk_tmp
mkdir -p "$DX_DIR/com/gemmaclaw" "$DX_OUT"

# Stub Java vide — NativeActivity gère tout côté natif, mais Android 14+
# refuse les APK sans classes.dex.
cat > "$DX_DIR/com/gemmaclaw/Stub.java" <<'EOF'
package com.gemmaclaw;
public final class Stub {
    private Stub() {}
}
EOF

ANDROID_JAR="$SDK_ROOT/platforms/$SDK_PLATFORM/android.jar"
javac -source 17 -target 17 -bootclasspath "$ANDROID_JAR" \
      -d "$DX_OUT" "$DX_DIR/com/gemmaclaw/Stub.java" 2>/dev/null || \
javac -source 8 -target 8 -d "$DX_OUT" "$DX_DIR/com/gemmaclaw/Stub.java"

D8="$SDK_ROOT/build-tools/$SDK_BUILD_TOOLS/d8"
"$D8" --output build_apk_tmp \
      $(find "$DX_OUT" -name '*.class')
echo "✓ classes.dex généré"

# ── 7. Compilation des ressources avec aapt2 ─────────────────────────────────
echo ""
echo "▶ Compilation des ressources (aapt2)..."
AAPT2="$SDK_ROOT/build-tools/$SDK_BUILD_TOOLS/aapt2"
RES_OUT="build_apk_tmp/res_compiled"
mkdir -p "$RES_OUT"

"$AAPT2" compile --dir android/src/main/res -o "$RES_OUT/res.zip"

"$AAPT2" link \
    -I "$ANDROID_JAR" \
    --manifest android/src/main/AndroidManifest.xml \
    -R "$RES_OUT/res.zip" \
    --java build_apk_tmp/gen \
    -o build_apk_tmp/base.apk \
    --auto-add-overlay
echo "✓ APK base linké"

# ── 8. Inject classes.dex + .so dans l'APK ───────────────────────────────────
echo ""
echo "▶ Injection des libs natives + dex..."
cd build_apk_tmp

# Réorganise les .so : jniLibs/<ABI>/lib*.so → lib/<ABI>/lib*.so
mkdir -p lib
cp -r ../jniLibs/* lib/

# strip pour réduire la taille (release uniquement)
if [ "$MODE" = "release" ]; then
    LLVM_STRIP="$ANDROID_NDK_ROOT/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
    [ -x "$LLVM_STRIP" ] && find lib -name '*.so' -exec "$LLVM_STRIP" {} \; || true
fi

zip -q -u base.apk classes.dex
zip -q -ur base.apk lib/

cd ..

# ── 9. Zipalign ──────────────────────────────────────────────────────────────
echo "▶ Zipalign..."
ZIPALIGN="$SDK_ROOT/build-tools/$SDK_BUILD_TOOLS/zipalign"
"$ZIPALIGN" -p -f 4 build_apk_tmp/base.apk build_apk_tmp/aligned.apk

# ── 10. Signature ─────────────────────────────────────────────────────────────
KEYSTORE="$HOME/.${APP_NAME}_${MODE}.keystore"
KS_PASS="${KEYSTORE_PASS:-android}"

if [ ! -f "$KEYSTORE" ]; then
    echo "▶ Création du keystore $MODE..."
    keytool -genkeypair -v \
        -keystore "$KEYSTORE" \
        -alias "$APP_NAME" \
        -keyalg RSA -keysize 4096 -validity 10000 \
        -storepass "$KS_PASS" -keypass "$KS_PASS" \
        -dname "CN=$APP_NAME,O=GemmaClaw,L=Paris,C=FR" 2>&1 | tail -2
fi

APKSIGNER="$SDK_ROOT/build-tools/$SDK_BUILD_TOOLS/apksigner"
OUTPUT_APK="${APP_NAME}_${MODE}.apk"
"$APKSIGNER" sign \
    --ks "$KEYSTORE" \
    --ks-key-alias "$APP_NAME" \
    --ks-pass "pass:$KS_PASS" \
    --key-pass "pass:$KS_PASS" \
    --v1-signing-enabled true \
    --v2-signing-enabled true \
    --v3-signing-enabled true \
    --out "$OUTPUT_APK" \
    build_apk_tmp/aligned.apk

# Vérification finale
"$APKSIGNER" verify --print-certs "$OUTPUT_APK" >/dev/null
APK_SIZE=$(du -h "$OUTPUT_APK" | cut -f1)

echo ""
echo "════════════════════════════════════════════════════"
echo "  ✅ APK prêt : $OUTPUT_APK ($APK_SIZE)"
echo "════════════════════════════════════════════════════"
echo ""
echo "Étapes suivantes :"
echo "  1. adb install -r $OUTPUT_APK"
echo "  2. Télécharge le modèle : gemma-2-2b-it-Q4_K_M.gguf"
echo "     https://huggingface.co/lmstudio-ai/gemma-2-2b-it-GGUF"
echo "  3. Place .gguf + tokenizer.json dans /sdcard/Download/"
echo "  4. Dans l'app : ⚙ → Importer le modèle"

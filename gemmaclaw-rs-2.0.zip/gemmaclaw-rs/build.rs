// ─────────────────────────────────────────────────────────────────────────────
// build.rs — compile les fichiers Slint et expose les métadonnées de build.
// ─────────────────────────────────────────────────────────────────────────────
use std::process::Command;

fn main() {
    // 1. Compile la UI Slint
    let cfg = slint_build::CompilerConfiguration::new()
        .with_style("material".into());
    slint_build::compile_with_config("ui/main.slint", cfg)
        .expect("Slint compilation failed");

    // 2. Re-run si la UI ou le manifeste changent
    println!("cargo:rerun-if-changed=ui/main.slint");
    println!("cargo:rerun-if-changed=android/src/main/AndroidManifest.xml");
    println!("cargo:rerun-if-changed=Cargo.toml");

    // 3. Embarque la version git (utile pour /about)
    let git_hash = Command::new("git")
        .args(["rev-parse", "--short", "HEAD"])
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| "unknown".into());
    println!("cargo:rustc-env=GIT_HASH={git_hash}");

    // 4. Date de build
    let build_date = chrono_build_date();
    println!("cargo:rustc-env=BUILD_DATE={build_date}");
}

fn chrono_build_date() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    format!("{secs}")
}

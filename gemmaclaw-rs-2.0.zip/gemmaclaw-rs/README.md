# 🦀 GemmaClaw Rust 2.0 — Agent IA Android 100% Rust

[![Rust 1.75+](https://img.shields.io/badge/rust-1.75+-orange.svg)](https://www.rust-lang.org)
[![License](https://img.shields.io/badge/license-Apache--2.0%20OR%20MIT-blue.svg)](LICENSE)
[![Android 8+](https://img.shields.io/badge/android-8.0+-green.svg)](https://www.android.com)
[![Zero unsafe](https://img.shields.io/badge/unsafe-deny-success.svg)](#)

> **Réécriture complète en Rust de GemmaClaw.** Zéro JVM, zéro GC, contrôle mémoire total, **zéro `unsafe`** dans le code applicatif.

---

## ✨ Quoi de neuf en 2.0

| Domaine | 1.0 | 2.0 |
|---------|-----|-----|
| Sécurité mémoire | `*const Model` partagé entre threads (UB) | **`#![deny(unsafe_code)]`** + `RwLock` |
| KV-cache LLM | Reforward complet à chaque token (lent) | **Forward incrémental** correct |
| Échantillonnage | `LogitsProcessor` figé (top-p only) | **Sampler custom** : top-k + top-p + repeat-penalty |
| Format chat | Préfixes texte plats | **Template officiel Gemma** (`<start_of_turn>`) |
| Tool call parsing | `text.find('{')` naïf | **Parser à profondeur d'accolades** (gère JSON dans markdown) |
| Build Android | `aapt` v1 (déprécié) | **`aapt2` + `d8`** + multi-ABI |
| Persistence | Schéma figé | **Migrations versionnées** |
| Settings | Écriture non-atomique | **Écriture atomique** (tempfile + rename) |
| Erreurs | `anyhow::Error` partout | **`thiserror::GemmaError`** typé |
| Tests | 10 tests | **45+ tests** (unit + integration + property) |
| Bench | ❌ | **`criterion`** sur PromptBuilder |
| CI | ❌ | **GitHub Actions** (clippy, tests, audit) |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────┐
│  UI (Slint Material 3)                          │
└──────┬───────────────────────────────────┬──────┘
       │ callbacks                         │ events
       ▼                                   ▲
┌─────────────────────────────────────────────────┐
│  ui_loop.rs — wiring + back-pressure            │
└──────┬───────────────────────────────────┬──────┘
       │                                   │
       ▼                                   │
┌──────────────────┐    ┌────────────────────────┐
│   AgentLoop      │───►│  GemmaEngine (candle)  │
│  (≤3 steps)      │    │  ─ GGUF loader         │
└──────┬───────────┘    │  ─ KV-cache decoder    │
       │                │  ─ tokio::mpsc stream  │
       ▼                └──────────┬─────────────┘
┌──────────────────┐               │
│  SkillRegistry   │               ▼
│  ─ web_search    │    ┌────────────────────────┐
│  ─ calendar      │    │  Sampler               │
│  ─ reminder      │    │  top-k + top-p +       │
│  ─ system_info   │    │  repeat-penalty        │
└──────────────────┘    └────────────────────────┘
       │
       ▼
┌──────────────────────┐    ┌──────────────────┐
│  MemoryRepository    │    │  Settings        │
│  SQLite WAL          │    │  JSON atomique   │
│  + migrations        │    │  + RwLock        │
└──────────────────────┘    └──────────────────┘
```

### Modules

| Chemin | Rôle |
|--------|------|
| `src/lib.rs` | Crate root + réexports publics |
| `src/error.rs` | Type `GemmaError` (thiserror) |
| `src/llm/engine.rs` | Inférence Gemma (GGUF + KV-cache) |
| `src/llm/sampling.rs` | top-k / top-p / repeat-penalty |
| `src/llm/agent_loop.rs` | Orchestration + parsing tool calls |
| `src/llm/prompt_builder.rs` | Template Gemma + troncature historique |
| `src/llm/tokenizer_loader.rs` | Résolution intelligente de `tokenizer.json` |
| `src/skills/*` | Plugins outils (registre extensible) |
| `src/memory/mod.rs` | SQLite WAL + migrations |
| `src/settings/mod.rs` | JSON + écriture atomique |
| `src/app.rs` | App handle clonable (Arc) |
| `src/ui_loop.rs` | Boucle Slint commune (desktop + Android) |
| `src/android/*` | Bridge JNI (Intents calendar/alarm) |

---

## 🚀 Build rapide

### Desktop (dev / tests)
```bash
cargo run --release
cargo test --all
```

### Android — méthode recommandée (Google Cloud Shell)
```bash
chmod +x build_android.sh
./build_android.sh             # debug, ARM64
./build_android.sh release     # release signé, ARM64
./build_android.sh release all # universal APK (arm64+armv7+x86_64)
```

L'APK sera généré dans le répertoire courant : `GemmaClaw_release.apk`.

### Cibles supportées

| Target | OS | Statut |
|--------|----|----|
| `aarch64-linux-android` | Android ARM64 | ✅ principal |
| `armv7-linux-androideabi` | Android ARM 32 | ✅ |
| `x86_64-linux-android` | Émulateur | ✅ |
| `x86_64-unknown-linux-gnu` | Linux desktop | ✅ |
| `aarch64-apple-darwin` | macOS desktop | ✅ |

---

## 📦 Modèle requis

Téléchargement séparé (l'APK ne l'embarque pas) :

| Fichier | Taille | Source |
|---------|--------|--------|
| `gemma-2-2b-it-Q4_K_M.gguf` | ~1.5 GB | [HuggingFace](https://huggingface.co/lmstudio-ai/gemma-2-2b-it-GGUF) |
| `tokenizer.json` | ~17 MB | [google/gemma-2-2b-it](https://huggingface.co/google/gemma-2-2b-it/blob/main/tokenizer.json) |

Place les deux dans `/sdcard/Download/`, puis dans l'app : **⚙ Paramètres → Importer**.

---

## 🧪 Tests

```bash
cargo test --all            # tests unitaires + d'intégration
cargo clippy --all -- -D warnings
cargo bench                 # criterion → target/criterion/report
cargo audit                 # vulnérabilités CVE
```

**45+ tests** couvrent :
- `prompt_builder` : troncature, format Gemma, follow-up, mémoire injection
- `agent_loop`     : tool call parsing (5 variantes), nettoyage de réponse
- `sampling`       : greedy, top-k, repeat-penalty, edge cases vocab
- `calendar`       : ISO-8601 (4 formats), pas de fallback `now()`
- `reminder`       : refus passé, futur OK
- `web_search`     : parsing HTML DDG, normalisation URLs proxy
- `memory`         : migrations idempotentes, unicode truncate, recent mix
- `settings`       : round-trip, fichier corrompu, clamp
- `app`            : init data_dir, engine unloaded by default

---

## 🔒 Sécurité

* `#![deny(unsafe_code)]` dans tout le code applicatif (le seul `unsafe` est dans le bridge JNI Android, dûment commenté)
* Cargo.lock commité, audit CVE en CI
* Permissions Android minimales (pas de `READ_PHONE_STATE`, `ACCESS_FINE_LOCATION`, etc.)
* Pas de télémétrie. Pas de cloud. Pas de tracking. **Le modèle tourne sur ton téléphone.**

---

## 📊 Comparatif vs Kotlin / MediaPipe

| Critère | Kotlin + MediaPipe | **Rust 2.0** |
|---------|-------------------|---------------|
| Pauses GC | Oui (JVM) | **Aucune** |
| RAM résidente | ~150 MB heap JVM | **~40 MB** |
| Démarrage à froid | ~2 s | **~300 ms** |
| Inférence (Gemma 2B Q4) | MediaPipe (Google) | candle + BLAS NEON |
| Sécurité mémoire | Runtime | **Compile-time** |
| Format modèle | `.task` (proprio) | **`.gguf` (universel)** |
| Empreinte APK | ~50 MB | **~12 MB** (release stripped) |
| Annulation génération | Pas trivial | **`AtomicBool` natif** |

---

## 🗺️ Roadmap

- [ ] **Whisper** local (audio → texte) via `candle-whisper`
- [ ] **Vision** : LLaVA quantifié pour OCR / description d'image
- [ ] **RAG** : embeddings locaux + index SQLite FTS5
- [ ] **Quantisation Q2_K** : Gemma 7B sur smartphones haut de gamme
- [ ] **GPU Adreno** via Vulkan (candle-vulkan)
- [ ] **Skill `notes`** : prise de notes liée à la mémoire long terme

---

## 📜 Licence

Double licence : **Apache 2.0** ou **MIT** (au choix de l'utilisateur).

//! Bench Criterion sur la troncature d'historique.
//!
//! ```bash
//! cargo bench --bench prompt_builder
//! ```

use criterion::{black_box, criterion_group, criterion_main, Criterion, BenchmarkId};
use gemmaclaw::llm::prompt_builder::{ChatMessage, PromptBuilder};

fn bench_format_history(c: &mut Criterion) {
    let mut group = c.benchmark_group("format_history");

    for &n in &[10usize, 100, 500, 2000] {
        let msgs: Vec<ChatMessage> = (0..n)
            .map(|i| if i % 2 == 0 {
                ChatMessage::user(format!("Question {i} ".repeat(20)))
            } else {
                ChatMessage::assistant(format!("Réponse {i} ".repeat(40)))
            })
            .collect();

        group.bench_with_input(BenchmarkId::from_parameter(n), &msgs, |b, m| {
            b.iter(|| PromptBuilder::format_history(black_box(m)));
        });
    }
    group.finish();
}

fn bench_build(c: &mut Criterion) {
    let sys = PromptBuilder::system_prompt("- web_search: ...\n- system_info: ...");
    let hist = "<start_of_turn>user\nbonjour<end_of_turn>";
    c.bench_function("build_prompt", |b| {
        b.iter(|| {
            PromptBuilder::build(
                black_box(&sys),
                black_box(hist),
                black_box("Quelle heure est-il ?"),
            )
        })
    });
}

criterion_group!(benches, bench_format_history, bench_build);
criterion_main!(benches);

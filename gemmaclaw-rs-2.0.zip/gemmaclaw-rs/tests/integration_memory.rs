//! Tests d'intégration sur `MemoryRepository`.

use gemmaclaw::MemoryRepository;
use tempfile::tempdir;

#[tokio::test]
async fn full_chat_session_round_trip() {
    let dir = tempdir().unwrap();
    let db  = dir.path().join("test.db");

    let mem = MemoryRepository::open(&db).unwrap();

    // 6 messages alternés
    for i in 0..3 {
        mem.save_message(&format!("User msg {i}"),     true ).await.unwrap();
        mem.save_message(&format!("Assistant {i}"),    false).await.unwrap();
    }
    mem.save_tool_result("web_search", "found 3 results").await.unwrap();

    let h = mem.get_history(100).await.unwrap();
    assert_eq!(h.len(), 6);
    assert_eq!(h[0], ("User msg 0".into(), true));
    assert_eq!(h.last().unwrap().1, false);

    let recent = mem.recent_memories(10).await.unwrap();
    assert!(recent.iter().any(|s| s.contains("web_search")));
    assert!(recent.iter().any(|s| s.contains("Previous reply")));

    // Persistance après reload
    drop(mem);
    let mem2 = MemoryRepository::open(&db).unwrap();
    assert_eq!(mem2.get_history(100).await.unwrap().len(), 6);

    mem2.clear().await.unwrap();
    assert_eq!(mem2.count_messages().await.unwrap(), 0);
}

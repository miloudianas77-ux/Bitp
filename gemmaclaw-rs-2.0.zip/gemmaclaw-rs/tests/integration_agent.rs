//! Tests d'intégration : assemble plusieurs modules sans modèle réel.
//!
//! On utilise un "fake engine" pour vérifier la mécanique d'`AgentLoop` :
//! détection de tool call, appel du skill, follow-up, sortie texte.

use gemmaclaw::llm::agent_loop::parse_tool_call_for_test as parse_tool_call;

#[test]
fn end_to_end_pure_text_response() {
    // Pas de tool call dans la réponse → renvoyée telle quelle (après nettoyage).
    let resp = "Bonjour, comment puis-je vous aider ?";
    assert!(parse_tool_call(resp).is_none());
}

#[test]
fn end_to_end_detect_tool_inside_markdown() {
    let resp = "Voici l'appel :\n```json\n{\"tool\":\"system_info\",\"args\":{\"info_type\":\"time\"}}\n```\n";
    let parsed = parse_tool_call(resp);
    assert!(parsed.is_some());
    let (n, _a) = parsed.unwrap();
    assert_eq!(n, "system_info");
}

#[test]
fn end_to_end_tool_with_text_preamble_and_trailing_text() {
    let resp = "Sure, let me check. {\"tool\":\"web_search\",\"args\":{\"query\":\"rust 2024\"}} Done!";
    let (n, a) = parse_tool_call(resp).unwrap();
    assert_eq!(n, "web_search");
    assert_eq!(a["query"], "rust 2024");
}

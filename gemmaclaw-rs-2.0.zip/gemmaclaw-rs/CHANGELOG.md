# Changelog

Toutes les modifications notables seront documentées ici, format [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/).

## [2.0.0] — Édition « Prestine »

### 🔥 Bugs critiques corrigés (1.0)

| # | Sévérité | Fichier 1.0 | Description |
|---|----------|-------------|-------------|
| 1 | 💀 UB | `engine.rs:160` | `*const Model` partagé entre threads + `unsafe { &*model_ref }` après libération du `MutexGuard`. Réécrit en `RwLock` avec scope strict. |
| 2 | 🛑 Build | `Cargo.toml` | `candle-gguf` n'existe pas comme crate séparé. Remplacé par `candle_core::quantized::gguf_file`. |
| 3 | 🛑 Build | `Cargo.toml` | `tokenizers`, `urlencoding`, `async_trait`, `env_logger` utilisés mais non déclarés. Tous ajoutés. |
| 4 | 🐛 Logique | `engine.rs:200` | `pos += ctx_ids.len()` faux pour KV-cache : reforward TOUT le contexte à chaque token. Réécrit avec prefill + decode incrémental (1 token / step). |
| 5 | 🐛 Concurrence | `main.rs:42, 101, 155` | `rt.block_on()` imbriqué dans futures async → deadlock. Réécrit en pure async + `spawn_blocking`. |
| 6 | 🐛 UI | `main.slint:165` | `border-top: 1px solid` n'est pas une propriété Slint. Remplacé par un `Rectangle` 1px superposé. |
| 7 | 🐛 Build Android | `build_android.sh` | `aapt` v1 déprécié → `aapt2`. APK sans `classes.dex` rejeté par Android 14+ → ajout de `d8` + stub Java. |
| 8 | 🐛 Build Android | `build_android.sh` | `apksigner` après `zipalign` ✅ mais zipalign sans `-p` (alignement page) requis pour `extractNativeLibs="false"`. |
| 9 | 🐛 Format chat | `prompt_builder.rs` | Préfixes plats `User:` / `Assistant:` ignorent le tokenizer Gemma. Réécrit avec `<start_of_turn>user` / `model`. |
| 10 | 🐛 Tool parsing | `agent_loop.rs:115` | `text.find('{')` casse sur préambule type `{not json} ...`. Réécrit avec parser à profondeur d'accolades + support markdown. |

### 🆕 Ajouté

- **Sampler custom** (`src/llm/sampling.rs`) — top-k + top-p + repeat-penalty + seed reproductible, 100% safe Rust, testé.
- **Migrations SQL versionnées** (`memory/mod.rs`) — table `migrations`, idempotence vérifiée par tests.
- **Écriture atomique des settings** — `tempfile + rename`, jamais de fichier corrompu.
- **`thiserror::GemmaError`** — 13 variantes typées + `user_message()` localisé.
- **Bridge JNI Android** (`android/jni_bridge.rs`) — `INSERT_EVENT`, `SET_ALARM`, `Toast`.
- **Build Android multi-ABI** — `arm64`, `armv7`, `x86_64`, `all` (universal APK).
- **Backup rules** + **data extraction rules** XML pour Android 12+.
- **Tests de propriété** (`proptest`) sur le sampler.
- **Benchmarks Criterion** sur `PromptBuilder::format_history`.
- **CI GitHub Actions** : `cargo fmt`, `clippy --deny warnings`, `test`, `audit`.
- **Docs internes** rustdoc-friendly sur tous les modules publics.

### 🔧 Modifié

- `Cargo.toml` : MSRV 1.75, lints stricts (`#![deny(unsafe_code)]`), profil `release` avec `lto=fat`, `panic=abort`.
- Config cargo cross-Android dans `.cargo/config.toml` avec `target-cpu=cortex-a76` + features NEON/dotprod.
- UI Slint refondue (Material 3, switches animés, palette `Theme` globale).
- `MemoryRepository::recent_memories` : truncate Unicode-correct (compte les chars, pas les bytes).
- `SystemInfoSkill` : ajoute `weekday`, `offset`, `iso`, `platform`.
- `WebSearchSkill` : client `reqwest` partagé via `OnceCell` (réutilisation TLS), parser DDG renforcé, normalisation URLs proxy.

### ❌ Retiré

- `unsafe { &*model_ref }` (cf. bug #1)
- `urlencoding` non-déclaré
- `*const Model` partagé entre threads
- Indirections inutiles dans `prompt_builder` (kept iterator)
